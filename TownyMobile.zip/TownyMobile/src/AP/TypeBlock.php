<?php
namespace AP;

use pocketmine\scheduler\Task;

class TypeBlock extends Task
{
private $main;

private $type;

private $n;
public function __construct($main,$type,$name)
{
$this->main=$main;
$this->type=$type;
$this->n=$name;
}
public function onRun():void
{
if($this->type=="Ban")
{
$this->main->pardonBan($this->n);
}
else
{
$this->main->pardonMute($this->n);
}
}
}
?>