<?php

namespace AP;
use AP\Fishing;
use BedrockProtocol\PlaySoundPacket;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\ItemIds;
use pocketmine\inventory\CraftingGrid;
use pocketmine\network\mcpe\protocol\ContainerOpenPacket;
use pocketmine\network\mcpe\protocol\types\WindowTypes;
use pocketmine\entity\EffectInstance;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Hoe;
use pocketmine\item\Axe;
use pocketmine\item\Pickaxe;
use pocketmine\item\Shovel;
use pocketmine\item\Sword;
use pocketmine\world\Position;
use jasonwynn10\ScoreboardAPI\ScoreboardEntry;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\scheduler\TaskScheduler;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\entity\effect\Effect;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\item\ItemFactory;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\block\BlockFactory;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\entyty\effect\VanillaEffects;
use pocketmine\color\Color;
use pocketmine\level\sound\
{
    AnvilBreakSound,
    AnvilFallSound,
    AnvilUseSound,
    BlazeShootSound,
    ClickSOund,
    DoorBumpSound,
    DoorCrashSound,
    DoorSound,
    EndermanTeleportSound,
    FizSound,
    GenericSound,
    GhastShootSound,
    GhastSound,
    LaunchSound,
    PopSound
};
use pocketmine\utils\Config;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\inventory\AnvilInventory;
use pocketmine\player\GameMode;

class AP extends PluginBase implements Listener
{
	public $config,$level,$pk,$chunk,$sb,$sbapi,$fractionnicks,$sc,$serialnum,$moneybal,$message,$name,$ac,$ai;
	public function onBreak(BlockBreakEvent $e)
	{
	$p=$e->getPlayer();
	$n=$p->getName();
	$b=$e->getBlock();
	$cx=$b->getPosition()->getX()>>4;
    $cz=$b->getPosition()->getZ()>>4;
        $x=$b->getPosition()->getX();
        $y=$b->getPosition()->getY();
        $z=$b->getPosition()->getZ();
    $id=$b->getId();
	if($this->config->exists("$cx $cz"))
	{
		$owner=$this->config->get("$cx $cz");
	
		if($n=="Admin")
		{if($id==56)
		{
		$item=ItemFactory::getInstance()->get(264,0,rand(1,5));
		$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
		$i->setNameTag("Бонуспредмет");
		$i->setNameTagVisible(true);
		$i->setNameTagAlwaysVisible(true);
		}
		else if($id==16)
		{
		$item=ItemFactory::getInstance()->get(263,0,rand(1,5));
		$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
		$i->setNameTag("Бонуспредмет");
		$i->setNameTagVisible(true);
		$i->setNameTagAlwaysVisible(true);
		}
		}
		else if($owner==$n)
		{
	      if($id==56)
	      {
	      $item=ItemFactory::getInstance()->get(264,0,rand(1,5));
	      $i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
	      $i->setNameTag("Бонуспредмет");
	      $i->setNameTagVisible(true);
	      $i->setNameTagAlwaysVisible(true);
	      }
	      else if($id==16)
	      {
	      $item=ItemFactory::getInstance()->get(263,0,rand(1,5));
	      $i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
	      $i->setNameTag("Бонуспредмет");
	      $i->setNameTagVisible(true);
	      $i->setNameTagAlwaysVisible(true);
	      }
		}
		else
		{
			if($this->config->exists("$owner"))
			{
				$town=$this->config->get("town$n");
				if($this->config->get("$owner")==$n && $owner==$town)
				{
				if($id==56)
				{
				$item=ItemFactory::getInstance()->get(264,0,rand(1,5));
				$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
				$i->setNameTag("Бонуспредмет");
				$i->setNameTagVisible(true);
				$i->setNameTagAlwaysVisible(true);
				}
				else if($id==16)
				{
				$item=ItemFactory::getInstance()->get(263,0,rand(1,5));
				$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
				$i->setNameTag("Бонуспредмет");
				$i->setNameTagVisible(true);
				$i->setNameTagAlwaysVisible(true);
				}
				
				}
				else
				{
					$e->cancel();
					$p->sendMessage("§l§cНовая система не позволяет тут ломать блоки.");
				}
			}
			else
				{
				$e->cancel();
				}
		}
	}
	else
	{
	if($id==56)
	{
	$item=ItemFactory::getInstance()->get(264,0,rand(1,5));
	$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
	$i->setNameTag("Бонуспредмет");
	$i->setNameTagVisible(true);
	$i->setNameTagAlwaysVisible(true);
	}
	else if($id==16)
	{
	$item=ItemFactory::getInstance()->get(263,0,rand(1,5));
	$i=$this->getServer()->getWorldManager()->getWorldByName("world")->dropItem(new Vector3($x,$y,$z),$item);
	$i->setNameTag("Бонуспредмет");
	$i->setNameTagVisible(true);
	$i->setNameTagAlwaysVisible(true);
	}
	
	}
	
	}
	public function onPlace(BlockPlaceEvent $e)
	{
	$p=$e->getPlayer();
	$n=$p->getName();
$b=$e->getBlock();
$cx=$b->getPosition()->getX()>>4;
    $cz=$b->getPosition()->getZ()>>4;
	if($this->config->exists("$cx $cz"))
	{
		$owner=$this->config->get("$cx $cz");
	if($n=="Admin")
	{
	
	}
		else if($owner==$n)
		{
	
		}
		else
		{
			if($this->config->exists("$owner"))
			{
				$town=$this->config->get("town$n");
				if($this->config->get("$owner")==$n && $owner==$town)
				{
				
				}
				else
				{
					$e->cancel();
					$p->sendMessage("§l§cНовая система не позволяет тут взаимодействовать.");
						}
			}
			else
				{
				$e->cancel();
}
		}
	}
	else
	{
	
	}
	
	}
	public function playChallenge($pl)
	{
	}
	public function playMusic()
	{
	}
	public function playChallengeS($p)
	{
	}
	public function Airdrop()
	{
		
		$x=rand(-100,-120);
		$z=rand(-100,-120);
		$chunk=$this->getServer()->getWorldManager()->getWorldByName("world")->getChunk($x >> 4,$z>>4);
		$cx=$x>>4;
		$cz=$z>>4;
		$ys=[];
		$this->getLogger()->info("$cx $cz");
		$y=70;
		$level=$this->getServer()->getWorldManager()->getWorldByName("world");
		$level->loadChunk($cx,$cz);
		$server=$this->getServer();
		$level->setBlock(new Vector3($x,$y,$z),BlockFactory::getInstance()->get(54,0));
    $chest = $level->getTile(new Vector3($x,$y,$z));
	$inv=$chest->getRealInventory();
	$items=[];
	$rid=rand(276,279);
		$item=ItemFactory::getInstance()->getInstance()->get($rid,0,1);
		for($position=2;$position<8;$position++)
		{
			$ran=rand(298,317);
			$iitem=ItemFactory::getInstance()->getInstance()->get($ran,0,1);
			array_push($items,$iitem);
		}
		array_push($items,$item);
			for($pos=0;$pos<count($items);$pos++)
			{
				$inv->setItem($pos,$items[$pos]);
			}
	$server->broadcastMessage("§l§cВНИМАНИЕ! §eСейчас был скинут AirDrop. Его координаты:§c$x $y {$z}§e, или же по координатам чанка §c$cx {$cz}.Удачной охоты.");
	$this->getLogger()->info("$x $y $z - AirDrop.");
	}
	public function onInteract(PlayerInteractEvent $e)
	{
		$p=$e->getPlayer();
		$gamemode=$p->getGamemode();
		$n=$p->getName();
		if($this->config->get("check$n")=="true")
		{
		$e->cancel();
		}
		if($p->getGamemode() == GameMode::CREATIVE())
		{
			if($n!="Admin" && $n!="EKZES95")
			{
				$p->disconnect("§l§cВы были забанены за читерство. §cВремя бана:§c30 дней.","Banned for cheats.");
				$this->ban($p,$p,"Читы(Fly | Creative)",20*60*60*24*30);
		}
	}
	if($p->isFlying()==true)
	{
		if(intval($this->config->get("donatelevel$n"))>=3)
		{}
		else
		{
			$p->disconnect("§l§cВы были забанены за читерство. §cВремя бана:§c30 дней.","Banned for cheats.");
			$this->ban($p,$p,"Читы(Fly | Creative)",20*60*60*24*30);
		}
	}
	if($this->getServer()->isOp($n) && $n!="Admin")
	{
$p->disconnect("§l§cВы были забанены за читерство. §cВремя бана:§c30 дней.","Banned for cheats.");
$this->ban($p,$p,"Читы(OP)",20*60*60*24*30);
	}
		$b=$e->getBlock();
		$pos=$b->getPosition();
		$x=$pos->getX();
		$y=$pos->getY();
		$z=$pos->getZ();
		$cx=$x>>4;
		$cz=$z>>4;
		if($this->config->exists("$cx $cz"))
		{
			$owner=$this->config->get("$cx $cz");
if($n=="Admin")
{

}
			else if($owner==$n)
			{

			}
			else
			{
				if($this->config->exists("$owner"))
				{
					$town=$this->config->get("town$n");
					if($this->config->get("$owner")==$n && $owner==$town)
					{
					
					}
					else
					{
						$e->cancel();
						$this->getServer()->getWorldManager()->getWorldByName("world")->setBlock(new Vector3($x,$y,$z),$b,true);
					$p->sendMessage("§l§cНовая система не позволяет тут взаимодействовать.");
					}
				}
				else
					{
						$e->cancel();
					$this->getServer()->getWorldManager()->getWorldByName("world")->setBlock(new Vector3($x,$y,$z),$b,true);
					$p->sendMessage("§l§cНовая система не позволяет тут взаимодействовать.");
					}
			}
		} 
		else
		{

		}
	if ($e->getBlock()!=null && $e->getBlock()->getId()==54)
	{
	$block=$e->getBlock();
	$chunk=$e->getPlayer()->getWorld()->getChunk($block->getPosition()->getX()>>4,$block->getPosition()->getZ()>>4);
	$cx=$block->getPosition()->getX()>>4;
	$cz=$block->getPosition()->getZ()>>4;
	$n=$e->getPlayer()->getName();
	$town=$this->config->get("town$n");
	if($this->config->exists("$cx $cz"))
	{
	$owner=$this->config->get("$cx $cz");
	$tp=["x x x"];
	if(!$this->config->exists("trust$town"))
	{
	$this->config->set("trust$town",[""]);
	$this->config->save();
	$tp=$this->config->get("trust$town");
	}
	else
	{
		$tp=$this->config->get("trust$town");
	}
	foreach($tp as $play)
	{
	if($owner===$e->getPlayer()->getName())
	{
	break;
	}
	else if($e->getPlayer()->getName()==$play)
	{
	break;
	}
	else if ($e->getPlayer()->getName()=="Admin")
	{
		break;
	}
	else
	{
	$n=$e->getPlayer()->getName();
	if($this->config->exists("$n"))
	{
	$to=$this->config->get("$n");
	$towner=$this->config->get("$to");
	if($owner==$n|| $n=="Admin" || $to==$owner && $towner==$n)
	{
	}
	else
	{
	$e->cancel();
	$e->getPlayer()->sendMessage("Сундук не ваш!");
	}
	}
	else
	{
	$e->cancel();
	$e->getPlayer()->sendMessage("Сундук не ваш!");
	}
	}
	}
	}
	else
	{
}
	}
	}
	public function pardonBan($n,$pn="Console",$why="разбан по времени")
	{
	$cfg=$this->config;
	if($cfg->exists("ban$n"))
	{
	$cfg->remove("ban$n");
		$cfg->remove("time$n");
		$cfg->remove("whobanned$n");
			$cfg->remove("reason$n");
	$cfg->save();
	$this->getServer()->broadcastMessage("§l§eИгрок §c$pn §eразбанил игрока $n по причине:§f$why");
	}
	}
	public function pardonMute($n,$pn="Console",$why="размут по времени")
	{
	$cfg=$this->config;
	if($cfg->exists("mute$n"))
	{
	$cfg->remove("mute$n");
	$cfg->remove("time$n");
	$cfg->remove("reason$n");
	$cfg->save();
	$this->getServer()->broadcastMessage("§l§eИгрок §c$pn §eразмутил игрока $n по причине:§f$why");
	}
	}
	public function ban($p,$bp,$reason="На вас наложена печать бана!",$time=1200*30)
	{
	$cfg=$this->config;
	$n=$p->getName();
	$bn=$bp->getName();
	if($cfg->exists("ban$n"))
	{
	$bp->sendMessage("§l§cИгрок уже забанен!");
	}
	else
	{
	$cfg->set("ban$n","true");
	$cfg->set("time$n",$time/20);
	$cfg->set("reason$n",$reason);
	$cfg->set("whobanned$n",$bn);
	$this->getScheduler()->scheduleDelayedTask(new TypeBlock($this,"Ban",$n),$time);
	$time=$time/20;
	$p->disconnect("§l§cВы были забанены игроком §e$bn §cпо причине:§f$reason \n§cВремя бана:§e$time сек.\n§eЕсли бан §cнеоправданный§e, обратитесь в поддержку в §bДискорде§e.","Banned for $time ticks by $bn");
	$this->getServer()->broadcastMessage("§l§c$n §eбыл забанен игроком §c$bn на $time сек. по причине:§f$reason");
	}
	}
	public function mute($p,$bp,$reason="На вас наложена печать мута!",$time=1200*30)
	{
	$cfg=$this->config;
	$n=$p->getName();
	$bn=$bp->getName();
	if($cfg->exists("mute$n") || $cfg->exists("ban$n"))
	{
	$bp->sendMessage("§l§cИгрок уже в муте или в бане!");
	}
	else
	{
	$cfg->set("mute$n","true");
	$cfg->set("time$n",$time/20);
	$cfg->set("reason$n",$reason);
	$this->getScheduler()->scheduleDelayedTask(new TypeBlock($this,"Mute",$n),$time);
	$time=$time/20;
	$this->getServer()->broadcastMessage("§l§c$n §eбыл замьючен игроком §c$bn на $time сек. по причине:§f$reason");
	}
	}
	public function kick($p,$kn)
	{
	$p->disconnect("§l§cВы были кикнуты игроком §e$kn","Kick by $kn");
	$n=$p->getName();
	$this->getServer()->broadcastMessage("§l§a$kn §eкикнул §c$n");
	}
	public function onQuit(PlayerQuitEvent $e)
	{
	$e->setQuitMessage("");
	}
	public function onLogin(PlayerLoginEvent $event)
	{
		$p=$event->getPlayer();
		$n = $p->getName(); //PlayerName
		if($this->config->exists("ban$n"))
	{
	$bn=$this->config->get("whobanned$n");
	$time=$this->config->get("time$n");
	$reason=$this->config->get("reason$n");
		$p->disconnect("§l§cВы были забанены игроком §e$bn §cпо причине:§f$reason \n§cВремя бана:§e$time сек.\n§eЕсли бан §cнеоправданный§e, обратитесь в поддержку в §bДискорде§e.","Ban not expired, ban by $bn for $time ticks");
		$event->cancel();
	}
	}
public function onJoin(PlayerJoinEvent $event):bool{
$tow="Нету";
	    $event->setJoinMessage("");
	$p = $event->getPlayer(); //Player
	$n = $p->getName(); //PlayerName
	$effects=$p->getEffects();
$money=$this->getMoney($p);
if($this->config->exists("ban$n"))
{
$bn=$this->config->get("whobanned$n");
$time=$this->config->get("time$n");
$reason=$this->config->get("reason$n");
	$p->disconnect("§l§cВы были забанены игроком §e$bn §cпо причине:§f$reason \n§cВремя бана:§e$time сек.\n§eЕсли бан §cнеоправданный§e, обратитесь в поддержку в §bДискорде§e.","Ban not expired, ban by $bn for $time ticks");

}
else
{
$p->sendTitle("§l§aПривет,$n !","§l§eПриятной игры!",20,20*5,20*2);
$this->config->set("xx$n",$p->getPosition()->getX());
$this->config->set("yy$n",$p->getPosition()->getY());
$this->config->set("zz$n",$p->getPosition()->getZ());
if(!$this->config->exists("donatelevel$n"))
{
$this->config->set("donatelevel$n",0);
}
if(!$this->config->exists("flymode$n"))
{
$this->config->set("flymode$n","0");
}
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if(!$this->config->exists("$town"))
{
$this->config->remove("town$n");
}
else
{
if(!$this->config->exists("vz$town"))
{
$this->config->set("vz$town","false");
}
else if($this->config->get("vz$town")=="true")
{
$effects->add(new EffectInstance(Effect::getEffect(VanillaEffects::SPEED()),new Color(0,255,0,0x00),999999,1,false));
$effects->add(new EffectInstance(Effect::getEffect(VanillaEffects::STRENGTH()),new Color(0,255,0,0x00),999999,1,false));
}
else
{
	$effects->clear();
}
}
}
if(!$this->config->exists("job$n"))
{
$this->config->set("job$n","0");
}
if(!$this->config->exists("money$n"))
{
$this->config->set("money$n","10");
}
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if(!$this->config->exists("age$town"))
{
$this->config->set("age$town","stone");
}
}
$p->teleport(new Vector3(10005,53,9882));
	if($this->config->exists("password$n"))
	{
$this->config->set("check$n",true);
$p->sendMessage("§l§aВведите пароль в чат");
	}
	else
	{
	$this->config->set("check$n",true);
	$p->sendMessage("§l§aВведите ваш новый пароль в чат");
	}
	if ($this->config->exists("showchunks$n"))
	{
	
	}
	else
	{
	$this->config->set("showchunks$n","no");
	$this->config->save();
	}
		$this->config->save();
	}
		return true;
	}

	public function giveMeal()
	{
	foreach($this->getServer()->getOnlinePlayers() as $p)
	{
	if(!$p->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(ItemIds::COOKED_PORKCHOP,0,64)))
	{
	$p->getInventory()->addItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::COOKED_PORKCHOP,0,4));
	}
	}
	}
public function onCommand(CommandSender $comsend,Command $ap,$label,array $args) : bool
{
if($comsend instanceof Player)
{
$co=$ap->getName();
 $pll=$comsend;
 $player=$pll;
 $p=$player;
$n=$pll->getName();
if ($this->config->get("check$n")===true)
{
$comsend->sendMessage("§l§cЗапрещено, пока не вошли.");
}
else
{
if ($co === "spawn")
{
 $pl=$comsend;
 $pl->teleport(new Position(5,68,10,$this->getServer()->getWorldManager()->getWorldByName("world")));
}
else if($co=="setskin")
{
if(isset($args[0]) && isset($agrs[1]))
{
if($this->getServer()->getPlayerExact($args[0])!=null)
{
$pl=$this->getServer()->getPlayerExact($args[0]);
$url=$args[1];
$file_name=basename($url);
$link=$this->getDataFolder().$file_name;
if(file_put_contents($link,file_get_contents($url)))
{
$this->SetSkin($pl,$link);
$player->sendMessage("Успешно");
}
else
{
$player->sendMessage("Неверный URL");
}
}
else
{
$player->sendMessage("Игрок оффлайн");
}
}
}
else if($co=="admintools")
{
if(intval($this->config->get("donatelevel$n"))>=5)
{
if(isset($args[0]))
{
$type=$args[0];
if($type=="ban")
{
if(isset($args[1]))
{
$pla=$this->getServer()->getPlayerExact($args[1]);
if($pla!=null)
{
$reason="";
if(isset($args[2]))
{
$time=intval($args[2])*20;
if(isset($args[3]))
{
for($id=3;$id<count($args);$id++)
{
$reason.=$args[$id];
$reason.=" ";
}
$this->ban($pla,$player,$reason,$time);
}
else
{
$this->ban($pla,$player,"На вас наложена печать бана!",$time);
}
}
else
{
$this->ban($pla,$player);
}
}
else
{
$player->sendMessage("Игрок не в сети.");
}
}
else
{
$player->sendMessage("Игрок не указан.");
}
}
else if($type=="say")
{
	$atype=intval($this->config->get("donatelevel$n"));
	
	if(isset($args[1]))
	{
	if($atype==5)
	{
		$msg="";
			for($id=1;$id<count($args);$id++)
			{
				$msg.=$args[$id];
				$msg.=" ";
			}
		$this->getServer()->broadcastMessage("§l§e[Мл. Админ]§c[{$n}]§eВнимание:§f$msg");
	}
	else if($atype==6)
	{
		$msg="";
			for($id=1;$id<count($args);$id++)
			{
				$msg.=$args[$id];
				$msg.=" ";
			}
		$this->getServer()->broadcastMessage("§l§c[Ст. Админ][{$n}]§eВнимание! §f$msg");
	}
	else if($atype==7)
	{
		$msg="";
			for($id=1;$id<count($args);$id++)
			{
				$msg.=$args[$id];
				$msg.=" ";
			}
		$this->getServer()->broadcastMessage("§l§e[==Создатель==]§c[{$n}]§eВНИМАНИЕ! §e$msg");
	}
	}
	else
	{
		$player->sendMessage("§l§cСообщение пустое!");
	}
}
else if($type=="mute")
{
if(isset($args[1]))
{
$pla=$this->getServer()->getPlayerExact($args[1]);
if($pla!=null)
{
$reason="";
if(isset($args[2]))
{
$time=intval($args[2])*20;
if(isset($args[3]))
{
for($id=3;$id<count($args);$id++)
{
$reason.=$args[$id];
$reason.=" ";
}
$this->mute($pla,$player,$reason,$time);
}
else
{
$this->mute($pla,$player,"На вас наложена печать бана!",$time);
}
}
else
{
$this->mute($pla,$player);
}
}
else
{
$player->sendMessage("Игрок не в сети.");
}
}
else
{
$player->sendMessage("Игрок не указан.");
}
}
else if($type=="kick")
{
if(isset($args[1]))
{
$pla=$this->getServer()->getPlayerExact($args[1]);
if($pla!=null)
{
$this->kick($pla,$n);
}
else
{
$player->sendMessage("Игрок не в сети.");
}
}
else
{
$player->sendMessage("Игрок не указан.");
}
}
else if($type=="pardonban")
{
if(isset($args[1]))
{
$pla=$this->getServer()->getPlayerExact($args[1]);
if($player!=null)
{
$reason="";
if(isset($args[2]))
{
for($id=2;$id<count($args);$id++)
{
$reason.=$args[$id];
$reason.=" ";
}
$this->pardonBan($args[1],$n,$reason);
}
else
{
$this->pardonBan($args[1],$n,"разбан игроком");
}
}
else
{
$player->sendMessage("Игрок не в сети.");
}
}
else
{
$player->sendMessage("Игрок не указан.");
}
}
else if($type=="pardonmute")
{
if(isset($args[1]))
{
$pla=$this->getServer()->getPlayerExact($args[1]);
if($player!=null)
{
$reason="";
if(isset($args[2]))
{
for($id=2;$id<count($args);$id++)
{
$reason.=$args[$id];
$reason.=" ";
}
$this->pardonMute($args[1],$n,$reason);
}
else
{
$this->pardonMute($args[1],$n,"размут игроком");
}
}
else
{
$player->sendMessage("Игрок не в сети.");
}
}
else
{
$player->sendMessage("Игрок не указан.");
}
}
else if($type=="gm")
{
if(intval($this->config->get("donatelevel$n")) >=6)
{
if(strtolower($player->getGamemode()->getEnglishName())=="survival")
{
$player->setGamemode(\pocketmine\player\GameMode::CREATIVE());
}
else
{
$player->setGamemode(\pocketmine\player\GameMode::SURVIVAL());
}
}
else
{
$player->sendMessage("Недостаточно прав!");
}
}
else if($type=="reports")
{
	$files = scandir($this->getServer()->getDataPath()."players/");
$players = [];
foreach($files as $file) {
    array_push($players,rtrim($file, ".dat"));
}
$p->sendMessage("§l§cДоступные репорты:");
foreach($players as $name)
{
	$rep=$this->config->get("report$name");
if($rep!=null)
{
	$p->sendMessage("§l§c{$name}:§f$rep");
}
}
}
else if($type=="tp")
{
if(isset($args[1]))
{
$na=$args[1];
$inform=false;
if($na=="here")
{
$na=$args[2];
$inform=true;
}
$p=$this->getServer()->getPlayerExact($na);
if($p!=null)
{
if($na!=$n)
{
$pos=$p->getPosition();
$player->teleport($pos);
$player->sendMessage("§l§eВы телепортировались к игроку §c$na");
if($inform)
{
$p->sendMessage("§l§cВас телепортировал игрок $n");
}
}
else
{
$player->sendMessage("§l§cНельзя телепортировать самого себя!");
}
}
else
{
$player->sendMessage("§l§cОшибка: $na не в сети.");
}
}
else
{
$player->sendMessage("§l§cУкажите ник или /admintools tp here Ник, чтобы телепортировать игрлка к себе!");
}
}
else
{
$player->sendMessage("Доступно:/admintools gm/kick/ban/mute/pardonban/pardonmute/[tp here]");
}
}
else
{
$player->sendMessage("Доступно:/admintools kick/ban/mute/pardonban/pardonmute/[tp here] ");
}
}
else
{
$player->sendMessage("Denied.");
}
}
else if($co=="report")
{
		if(isset($args[0]))
		{
			if($args[0]=="clear")
			{
				$this->config->remove("report$n");
				$this->config->save();
				$p->sendMessage("§l§eВаша заявка была очищена.");
			}
			else
			{
			$msg="";
			for($id=0;$id<count($args);$id++)
			{
				$msg.=$args[$id];
				$msg.=" ";
			}
			$time=date("Y-m-d H:i:s");
			$msg.=".§lОтправлено в $time";
			$this->config->set("report$n",$msg);
			$this->config->save();
			$p->sendMessage("§l§eВаша заявка зарегистрирована. На вашу заявку могут ответить:");
			foreach($this->getServer()->getOnlinePlayers() as $pl)
			{
				$na=$pl->getName();
				if(intval($this->config->get("donatelevel$na"))>=5)
				{
					$p->sendMessage("§l§c$na");
					$pl->sendMessage("§l§cНовая жалоба от игрока: §e{$n}§c.Посмотреть: /admintools reports");
				}
			}
		}
	}
}
else if($co=="melt")
{
	if($this->config->get("donatelevel$n")>=2)
	{
		$inv=$p->getInventory();
		foreach($inv->getContents() as $item)
		{
			$count=$item->getCount();
			$id=$item->getId();
			if($id==14)
			{
				$inv->addItem(ItemFactory::getInstance()->getInstance()->get(266,0,$count));
				$inv->removeItem($item);
				$p->sendMessage("§l§eПереплавлено $count золота.");
			}
			if($id==15)
			{
				$inv->addItem(ItemFactory::getInstance()->getInstance()->get(265,0,$count));
				$inv->removeItem($item);
				$p->sendMessage("§l§eПереплавлено $count железа.");
			}
		}
	}
	else
	{
		$p->sendMessage("§l§cПереплавлять руды можно только от §eПравоприемника II§c!");
	}
}
 else if ($co == "plot")
 {
 $player=$comsend;
 $n = $player->getName();
 $ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
 $px = $player->getPosition()->getX();
 $pz=$player->getPosition()->getZ();
 $cx=$player->getPosition()->getX()>>4;
 $cz=$player->getPosition()->getZ()>>4;
 if(isset($args[0]) && $args[0] === "claim")
 {
	 
 if ($this->config->exists("$cx $cz"))
 {
 $conn=$this->config->get("$cx $cz");
 $comsend->sendMessage("§l§d[PM]§cДанный участок принадлежит $conn");
 }
 else if ($this->config->get("$cx $cz") === $n)
 {
  $comsend->sendMessage("§l§d[PM]§cЭтот участок уже ваш!");
 }
 
 else
 {
 if ($this->getMoney($player) >= 2)
 {
 $this->reduceMoney($player,2);
 $this->config->set("$cx $cz",$n);
 $this->config->save();
  $comsend->sendTitle("§l§d[PlotManager]","§l§aУспешно запривачено!",20*2,20*5,20*2);
 }
 }
 }
 else if (isset($args[0]) && $args[0]==="perm")
 {
 if ($this->config->exists("perm$n"))
 {
 $player->sendTitle("§l§d[Plot Manager]","§l§cЛомание вкл!",10,20,10);
 $isBreak=$this->config->get("perm$n");
 if ($isBreak=="false")
 {
 $this->config->set("perm$n","true");
 }
 else
 {
 $player->sendTitle("§l§d[Plot Manager]","§l§cЛомание выкл!",10,20,10);
 $this->config->set("perm$n","false");
 }
 }
 else
 {
 $player->sendTitle("§l§d[Plot Manager]","§l§cЛомание выкл!",10,20,10);
 $this->config->set("perm$n","false");
 }
  $this->config->save();
 }
 else if(isset($args[0]) && $args[0] === "unclaim")
 {
  if ($this->config->exists("$cx $cz") && $this->config->get("$cx $cz")===$n)
  {
 
  $this->addMoney($player,1);
    $comsend->sendTitle("§l§d[PlotManager]","§l§aУчасток удален!",20*2,20*5,20*2);
  $this->config->remove("$cx $cz");
  $this->config->save();
  }
  else
  {
      $comsend->sendTitle("§l§d[PlotManager]","§l§aВы не владелец участка!",20*2,20*5,20*2);
  }
 }
 else
 {
	  $ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
 $px = $player->getPosition()->getX();
 $pz=$player->getPosition()->getZ();
 $cx=$player->getPosition()->getX()>>4;
 $cz=$player->getPosition()->getZ()>>4;
  $conn=$this->config->get("$cx $cz");
   $comsend->sendMessage("§l§e=====Инфо территории на§c $cx $cz §e =====§a\nВладелец:$conn\nПомощь по плагину: /plot perm - вкл/выкл ломание и установки блоков\n /plot claim - получить незаприваченный участок\n/plot unclaim - удалить участок");
 }
}
else if ($co === "t")
{
$player=$comsend;
$n = $player->getName();
$ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
$px = $player->getPosition()->getX();
$pz=$player->getPosition()->getZ();
$cx=$player->getPosition()->getX()>>4;
$cz=$player->getPosition()->getZ()>>4;
$a="";
//§
if (isset($args[0]))
{
$a = $args[0];
 if ($a==="rename")
 {
  $ia=$player->getInventory()->getItemInHand();
   $ih=$ia;
   $l=$ih->getId();
   if ($l===278)
   {
     $ix=ItemFactory::getInstance()->getInstance()->get(278,0,1);
    $ix->setCustomName("Бурило"); 
      $player->getInventory()->removeItem($player->getInventory()->getItemInHand());
     $player->getInventory()->addItem($ix);
     $player->sendMessage("Успешно!");
   }
   else if($l===285)
   {
     $ix=ItemFactory::getInstance()->getInstance()->get(285,0,1);
    $ix->setCustomName("Бурило"); 
      $player->getInventory()->removeItem($player->getInventory()->getItemInHand());
     $player->getInventory()->addItem($ix);
     $player->sendMessage("Успешно!");
   }
   else if ($l==257)
   {
     $ix=ItemFactory::getInstance()->getInstance()->get(257,0,1);
    $ix->setCustomName("Бурило"); 
      $player->getInventory()->removeItem($player->getInventory()->getItemInHand());
     $player->getInventory()->addItem($ix);
     $player->sendMessage("Успешно!");
   }
   else
   {
     $player->sendMessage("Не успешно!");
   }
 }
 else if($a=="trust")
 {
 if($this->config->exists("town$n"))
 {
 $town=$this->config->get("town$n");
 $owner=$this->config->get("$town");
 if(!$this->config->exists("trust$town"))
 {
 if($owner==$n)
 {
 $this->config->set("trust$town",[$args[1]]);
 $na=$args[1];
 $p->sendMessage("§l$na теперь имеет доступ к сундукам");
 }
 else
 {
 $player->sendMessage("§l§cВы не мэр!");
 }
 }
 else
 {
 $array=$this->config->get("trust$town");
 $istrust=0;
 foreach($array as $namee)
 {
 if($namee==$n || $owner==$n)
 {
 array_push($array,$args[1]);
 $na=$args[1];
 $this->config->set("trust$town",$array);
 $p->sendMessage("§l$na теперь имеет доступ к сундукам");
 $istrust=1;
 break;
 }
 else
 {
 
 }
 }
 if($istrust==0)
 {
  $p->sendMessage("§lВы не Мэр или вы недоверенный!");
 }
 }
 }
 else
 {
   $player->sendMessage("§l§cСоздайте город или станьте мером!");
 }
 }
 else if($a=="generatelucky")
 {
 if($n=="Admin")
 {
 $i=$p->getInventory();
 $ii=$i->getHeldItemIndex();
 $item=$i->getItem($ii);
 $lore=$item->getLore();
 array_push($lore,"Эта кирка принесет тебе больше ресурсов!");
 $item->setLore($lore);
 $i->setItem($ii,$item);
 }
 }
 else if($a=="phonk")
 {
 $this->playMusic();
 }
 else if($a=="getnether")
 {
 if($player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(49,0,32)))
 {
 if($this->config->exists("town$n"))
 {
 $this->playChallenge($player);
 $town=$this->config->get("town$n");
 $player->sendMessage("Ты открыл ад в своем городе!");
 $player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(49,0,32));
 $this->config->set("nether$town","true");
 $this->config->save();
 }
 else
 {
 $player->sendMessage("Все бы ничего, но ты не в городе!");
 }
 }
 else
 {
  $player->sendMessage("У тебя нету 32 обсидиана!");
 }
 }
 else if($a==="testsound")
 {
 $this->playChallenge($player);
 }
 else if($a=="setowner")
 {
	 if($this->config->exists("town$n"))
	 {
		$town=$this->config->get("town$n");
		if($this->config->get("$town")==$n)
		{
			if(isset($args[1]))
			{
				$name=$args[1];
				if($this->config->get("town$name")==$town)
				{
					$this->config->remove("$n");
					$this->config->set("$name","$town");
					$this->config->set("$town","$name");
					$player->sendMessage("§l§eВсе полномочия лидера города переданы §c{$name}§e.");
					if($this->config->exists("nation$town"))
					{
						$nat=$this->config->get("nation$town");
						$owner=$this->config->get("owner$nat");
						$inform=false;
						if($owner==$n)
						{
							$this->config->set("owner$nat","$name");
							$player->sendMessage("§l§eЛидерство в нации также передается §c{$name}");
							$inform=true;
						}
					$pl=$this->getServer()->getPlayerExact($name);
					if($pl!=null)
					{
						$pl->sendMessage("§lПоздравляем! Отныне вы - мэр вашего города.");
						if($inform==true)
						{
							$pl->sendMessage("§l§aТ.к. бывший лидер города был лидером вашей нации, вы теперь являетесь ее владельцем.");
						}
					}
				}
			}
			else
			{
				$player->sendMessage("§l§cНевозможно передать лидерство игроку из другого города.");
			}
			}
			else
			{
				$player->sendMessage("§l§cУкажите ник!");
			}
		}
		else
		{
			$player->sendMessage("§l§cВы не мэр!");
		}
	 }
	 else
	 {
		 $player->sendMessage("§l§cВы не в городе!");
	 }
 }
 else if($a=="kick")
 {
	 if($this->config->exists("town$n"))
	 {
		 $town=$this->config->get("town$n");
		 $owner=$this->config->get("$town");
		 if($owner==$n)
		 {
			 if(isset($args[1]))
			 {
				 $name=$args[1];
				 if($this->config->get("town$name")==$town)
				 { 
					 if($name!=$n)
					 {
						$this->config->remove("town$name");
						$player->sendMessage("§l§cВы выгнали $name с города.");
						$pl=$this->getServer()->getPlayerExact($name);
						if($pl!=null)
						{
							$pl->sendMessage("§l§cВы были изгнаны из города.");
						}
						foreach($this->getServer()->getOnlinePlayers() as $pla)
						{
							$nam=$pla->getName();
							if($this->config->get("town$nam")==$town)
							{
								$pla->sendMessage("§l§eЛидер изгнал $name из города");
							}
						}
					 }
					 else
					 {
						 $player->sendMessage("§l§cНельзя выгнать себя!");
					 }
				 }
				 else
				 {
					 $player->sendMessage("§l§cИгрок не в вашем городе, или вы не можете управлять другим городом.");
				 }
			 }
			 else
			 {
				 $player->sendMessage("§l§cУкажите ник!");
			 }
		 }
		 else
		 {
			 $player->sendMessage("§l§cВы не мэр!");
		 }
	 }
	 else
	 {
		 $player->sendMessage("§l§cВы не в городе!");
	 }
 }
 else if($a=="publish")
 {
 if($this->config->exists("town$n") && $this->config->exists("$n"))
 {
 if(isset($args[1]))
 {
 $sc=$args[1];
 if($sc=="news")
 {
 $msg="";
 for($id=2;$id<count($args);$id++)
 {
 $msg.=" ".$args[$id];
 }
 $town=$this->config->get("town$n");
 if(!$this->config->exists("news$town"))
 {
 $this->config->set("news$town","");
 }
 $msgs=$this->config->get("news$town");
 array_push($msgs,$msg);
 $this->config->set("news$town",$msgs);
 foreach($this->getServer()->getOnlinePlayers() as $p)
 {
 $na=$p->getName();
 $tow=$this->config->get("town$n");
 if($this->config->exists("town$na"))
 {
 $town=$this->config->get("town$na");
 if($town==$tow)
 {
 $p->sendMessage("§l§a[{$town}]§r§e".$msg);
 }
 }
 }
 }
 else if($sc=="rule")
 {
 
 }
 else
 {
 $player->sendMessage("§l§cНеверная команда. Доступно: /t publish news | rules");
 }
 }
 }
 else
 {
  $player->sendMessage("§l§cСоздайте город или станьте мером!");
 }
 }
 else if($a=="news")
 {
 if($this->config->exists("town$n"))
 {
 $town=$this->config->get("town$n");
 if(!$this->config->exists("news$town"))
 {
 $this->config->set("news$town","");
 $player->sendMessage("§l§c$town еще не обьявил новостей");
 }
 else
 {
 if(!isset($args[1]))
 {
 $msgs=$this->config->get("news$town");
 $player->sendMessage("§l§aНовости:");
 $id=1;
 foreach($msgs as $msg)
 {
 $player->sendMessage("{$id}.§l{$msg}\n");
 $id++;
 }
 }
 else
 {
 $townname=$args[1];
 if($this->config->exists("$townname"))
 {
 $news=$this->config->get("news$townname");
   $player->sendMessage("§l§aНовости {$townname}:");
$id=0; 
 foreach($news as $oi)
 {
  $player->sendMessage("{$id}.§l{$oi}\n");
  $id++;
 }
 }
 }
 }
 }
 else
 {
$player->sendMessage("§l§cВы не в городе!");
 }
 }
else if ($a === "new")
{	
if (isset($args[1]))
{
$s=$args[1];
if ($this->config->exists("$s"))
{
$player->sendMessage("§l§d[Town]§cДанный город уже создан!");
}
else if ($this->config->exists("town$n"))
{
$player->sendMessage("§l§d[Town]§cВы в городе!");
}
else
{
$mm=$this->getMoney($player);
if ($mm>=50)
{
$this->config->set("$s","$n");
$this->config->set("$n","$s");
$this->config->set("town$n","$s");
$this->config->set("$cx $cz","$s");
$this->config->set("money$s",0);
$this->config->set("tax$s",0);
$this->config->set("dd$s","false");
$this->config->set("rz$s","false");
$this->config->set("age$s","stone");
$this->config->set("nether$s","false");
$this->config->set("news$s","");
$this->config->set("vz$s","false");
$this->config->save();
$dp=$this->getDataFolder();
$file=$dp."towns.txt";
$cur=file_get_contents($file)."$s\n";
file_put_contents($file,$cur);
$player->sendTitle("§l§aГород §c$s §aсоздан!","/t help",20*2,20*7,20*2);
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$p->sendMessage("§a$n создал город §c$s");
$this->playChallenge($p);
}
}
else
{
$player->sendTitle("§l§cНедостаточно средств!","§l§cЗаработайте §a50¤!",20*2,20*7,20*2);
}}
}
else
{
$player->sendTitle("§l§eУкажите","§l§cназвание города!",20,20*3,20);
}
}
else if ($a==="war") //Waaaaaaarrrrr
{
if(isset($args[1]))
{
$tname=$args[1];
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$owner=$this->config->get("$town");
if ($owner===$n)
{
if($this->config->exists("$tname"))
{
$to=$this->config->get("$tname");
if ($this->getServer()->getPlayerExact("$to")!=null)
{
$this->getServer()->broadcastMessage("§l§c$town огласил войну {$tname}! Война закончится тогда,когда один из мэров напишет /t merge.");
$this->config->set("war$tname","$town");
$this->config->set("war$town","$tname");
}
else
{
$player->sendMessage("§l§c$to оффлайн.");
}
}
else
{
$player->sendMessage("§l§cГород $tname не найден!");
}
}
else
{
$player->sendMessage("§l§cВы не мэр!");
}
}
else
{
$player->sendMessage("§l§cУкажите название города!");
}
}
}
else if ($a==="pvp")
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$towner=$this->config->get("$town");
if ($towner === $n)
{
if($this->config->exists("pvp$town"))
{
$toggle=$this->config->get("pvp$town");
if($toggle==="false")
{
if($this->config->exists("war$town"))
{
$player->sendMessage("§l§cВо время войны данная команда недоступна.");
}
else
{
$this->config->set("pvp$town","true");
$player->sendMessage("§l§cPvP в $town теперь вкл.");
}
}
else
{
if($this->config->exists("war$town"))
{
$player->sendMessage("§l§cВо время войны данная команда недоступна.");
}
else
{
$this->config->set("pvp$town","false");
$player->sendMessage("§l§aPvP в $town теперь выкл.");
}
}
}
else
{
$this->config->set("pvp$town","true");
$player->sendMessage("§l§cPvP в $town теперь вкл.");
}
}
else
{
$player->sendMessage("§l§cВы не мэр!");
}
}
else
{
$player->sendMessage("§l§cВы не в городе!");
}

}
else if ($a==="merge")
{
	if ($this->config->exists("town$n"))
	{
		$ptown = $this->config->get("town$n");
		$mtn=$args[1];
		$owner=$this->config->get("$ptown");
		if ($n===$owner)
		{
		if ($this->config->exists("$mtn"))
		{
			$mergeowner=$this->config->get("$mtn");
			if ($this->getServer()->getPlayerExact("$mergeowner")->isOnline())
			{
				$p=$this->getServer()->getPlayerExact("$mergeowner");
				$p->sendMessage("§l§c$n отправил вам запрос на обьединение с городом $ptown ![/t acceptmerge][/t denymerge]");
				$player->sendMessage("§l§cЗапрос мэру города $mtn отправлен!");
				$this->config->set("merge$mtn","$ptown");
				$this->config->set("askmerge$mtn","true");
			}
			
			else
			{
				$player->sendMessage("§l§c$mergeowner оффлайн.");
			}
		}
		else
		{
				$player->sendMessage("§l§cГорода $mtn не существует.");
		}
		}
		else
		{
				$player->sendMessage("§l§cВы не мэр!");
		}
	}
	else
	{
				$player->sendMessage("§l§cВы не в городе!");
	}
}
else if ($a==="acceptmerge")
{
	if ($this->config->exists("town$n"))
	{
		$ptown=$this->config->get("town$n");
		$owner=$this->config->get("$ptown");
		if ($owner===$n)
		{
			if ($this->config->exists("merge$ptown"))
			{
				$asktown=$this->config->get("merge$ptown");
				$ato=$this->config->get("$asktown");
				$ownertown=$this->config->get("$ato");
					$ismerge=$this->config->get("askmerge$ptown");
					if ($ismerge==="true")
					{
					if($this->config->exists("war$ptown"))
					{
					$asktown=$this->config->get("war$ptown");
					$this->config->remove("war$ptown");
					$this->config->remove("war$asktown");
					$this->getServer()->broadcastMessage("§l§aВойна между $asktown и $ptown окончена. Победил город §c{$ato}!");
					}
						$this->config->set("town$n","$asktown");
						for($x=-2000;$x!=2000;$x++)
{
for($z=-2000;$z!=2000;$z++)
{
if ($this->config->exists("$x $z"))
{
$cow=$this->config->get("$x $z");
if ($cow===$ptown)
{
$player->sendMessage("§d§l$x $z §cбыл передан городу $asktown !");
$this->config->set("$x $z","$asktown");
}
}
}
}
$files=scandir($this->getServer()->getDataPath()."players/");
foreach($files as $m)
{
$name=rtrim($m,".dat");
if ($this->config->exists("town$name"))
{
$townn=$this->config->get("town$name");
if ($townn === $ptown)
{
$this->config->set("town$name","$asktown");
    $player->sendMessage("§l$name перемещен в $ato !");
    }
    }
   }
$dp=$this->getDataFolder();
$file=$dp."towns.txt";
$curr=file_get_contents($file);
$cur=rtrim($curr,"$ptown");
file_put_contents($file,$cur);
if ($this->config->exists("spawnx$ptown"))
{
$this->config->remove("spawnx$ptown");
$this->config->remove("spawny$ptown");
$this->config->remove("spawnz$ptown");
}
$this->config->remove("$ptown");
$this->config->remove("$n");
$this->config->remove("money$ptown");
$this->config->remove("tax$ptown");
$this->config->remove("nation$ptown");
$this->config->set("askmerge$ptown","false");
$this->getServer()->broadcastMessage("§l§c$ptown обьеденился с $asktown . $ptown удален, а все жители и территории теперь принадлежат $asktown");
					}
					else
					{
						$player->sendMessage("§l§cЗапросы на соединение не подавались.");
					}
			}
				else
				{
				$player->sendMessage("§l§cЗапросы на соединение не подавались.");
				}
			
		}
		else{
			$player->sendMessage("§l§cВы не мэр!");
		}
	}
	else
	{
		$player->sendMessage("§l§cВы не в городе!");
	}
}
else if ($a==="denymerge"){
	if ($this->config->exists("town$n"))
	{
		$ptown=$this->config->get("town$n");
		$owner=$this->config->get("$ptown");
		if ($owner===$n)
		{
			if ($this->config->exists("merge$ptown"))
			{
				$asktown=$this->config->get("merge$ptown");
				$ato=$this->config->get("$asktown");
				$ownertown=$this->config->get("$ato");
					$ismerge=$this->config->get("askmerge$ptown");
					if ($ismerge==="true")
					{
					if($this->getServer()->getPlayerExact("$ato")->isOnline())
				{
				$tpl=$this->getServer()->getPlayerExact("$ato");
				$tpl->sendMessage("Ваше предложние обьединения отклонено.");
				$pll->sendMessage("Вы отклонили предложение.");
				$this->config->set("askmerge$ptown","false");
				$this->config->remove("merge$ptown");
				}
				else
				{
				$pll->sendMessage("Лидер города-инициатора оффлайн.");
				}
	}
	else
	{
	$pll->sendMessage("Предложения об обьенинении не приходили.");
	}
	}
	else
	{
	$pll->sendMessage("Предложения об обьенинении не приходили.");
	}
	}
	else
	{
	$pll->sendMessage("Вы не мэр!");
	}
	}
	else
	{
	$pll->sendMessage("Вы не в городе!");
	}
}
else if ($a==="leave")
{
if ($this->config->exists("town$n"))
{
$pto=$this->config->get("town$n");
$this->config->remove("town$n");
$player->sendTitle("Успешно.","Все,ищи другой город...",10,40,10);
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$nam=$p->getName();
if ($this->config->exists("town$nam"))
{
$tow=$this->config->get("town$nam");
if ($tow===$pto)
{
$player->sendTitle("Игрок $n","ушел из города",10,40,10);
}
}
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не в городе!",10,20,10);
}
$this->config->save();
}
else if ($a === "delete")
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if($this->config->exists("$town"))
{
if ($this->config->exists("$n"))
{
$towner=$this->config->get("$town");
if ($towner === $n)
{
for($x=-2000;$x!=2000;$x++)
{
for($z=-2000;$z!=2000;$z++)
{
if ($this->config->exists("$x $z"))
{
$cow=$this->config->get("$x $z");
if ($cow===$town)
{
$player->sendMessage("§d§l$x $z §cбыл распривачен!");
$this->config->remove("$x $z");
}
}
}
}
$files=scandir($this->getServer()->getDataPath()."players/");
foreach($files as $m)
{
$name=rtrim($m,".dat");
if ($this->config->exists("town$name"))
{
$townn=$this->config->get("town$name");
if ($townn === $town)
{
$this->config->remove("town$name");
    $player->sendMessage("§l$name удален с города!");
    }
    }
   }
$dp=$this->getDataFolder();
$file=$dp."towns.txt";
$curr=file_get_contents($file);
$cur=rtrim($curr,"$town");
file_put_contents($file,$cur);
if ($this->config->exists("spawnx$town"))
{
$this->config->remove("spawnx$town");
$this->config->remove("spawny$town");
$this->config->remove("spawnz$town");
}
$this->config->remove("dd$town");
$this->config->remove("rz$town");
$this->config->remove("$town");
$this->config->remove("$n");
$this->config->remove("money$town");
$this->config->remove("town$n");
$this->config->remove("tax$town");
$this->config->remove("nation$town");
$player->sendTitle("§l§eГорода $town","§l§cБольше не существует...",20,20*3,20);
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$p->sendMessage("§l§cГорода §e$town §cбольше не существует...");
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не мэр!",10,20,10);
}
}
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не в городе!",10,20,10);
}
$this->config->save();
}
else if ($a === "ask")
{
if (!$this->config->exists("town$n"))
{
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$p->sendMessage("§a$n хочет вступить в город!§l§(/t add $n )");
}
}
else
{
$player->sendMessage("§l§cВы и так в городе!");
}
}
else if ($a==="add" && isset($args[1]))
{
$nick=$args[1];
if(isset($args[2]))
{
$nick.=" ".$args[2];
}
$player =$comsend;
if ($this->getServer()->getPlayerExact($nick) != null && $this->getServer()->getPlayerExact($nick)->isOnline())
{

if ($this->config->exists("town$n"))
{
$town = $this->config->get("$n");
$owner = $this->config->get("$town");
if ($owner === $n)
{
$an=$nick;
if ($this->config->exists("town$an"))
{
$t=$this->config->get("town$an");
$player->sendMessage("§l§cИгрок уже в городе $t");
}
else
{
$anp=$this->getServer()->getPlayerExact($an);
if ($player->getName() === $an)
{
$player->sendMessage("§l§aСам себя пригласить ты не можешь.");
}
else
{
if($this->config->exists("townask$n"))
{
$askt=$this->config->get("townask$n");
$player->sendMessage("§l§aВы не можете пригласить $an в город, т.к. город $askt уже пригласил его!");
}
else
{
$player->sendMessage("§l§aВы пригласили $an в город!");
$anp->sendMessage("§l§cВы приглашены в город $town ! (Принять: /t accept $town )(Отклонить: /t deny $town )");
$this->config->set("ask$town","$an");
$this->config->set("townask$an","$town");
$this->config->save();
}
}
}
}
else
{
$player->sendMessage("§l§aВы не мэр!");
}
}
else
{
$player->sendMessage("§l§aВы не в городе!");
}
}
else
{
$na=$args[1];
$player->sendMessage("§l§c$na оффлайн.");
}
}
else if ($a==="accept" && isset($args[1]))
{
if ($this->config->exists("townask$n"))
{
$at = $this->config->get("townask$n");
$vn=$this->config->get("ask$at");
if ($at === $args[1] && $vn===$n)
{
$this->config->set("town$n","$at");
$player->sendMessage("§l§aВы вступили в город $at !");

foreach($this->getServer()->getOnlinePlayers() as $p)
{
$na=$p->getName();
if ($this->config->get("town$na") === $at)
$p->sendMessage("§a$n в нашем городе!");
}
$this->config->remove("ask$at");
$this->config->remove("townask$vn");
$this->config->save();
}
}
}
else if ($a === "claim")
{	 
	if ($this->config->exists("$n"))
	 {	 $to = $this->config->get("$n");
		 $owto = $this->config->get("$to");
	 if ($owto != $n)
	 {
		 $comsend->sendMessage("§l§d[TM]§cВы не владелец города!");
	 }
else
{
	$ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
$px = $player->getPosition()->getX();
$pz=$player->getPosition()->getZ();
$cx=$player->getPosition()->getX();
$cz=$player->getPosition()->getX();
if ($this->config->exists("$cx $cz"))
{
	$cowner = $this->config->get("$cx $cz");
	$ptown = $this->config->get("town$n");
	if ($cowner === $n )
	{
		$this->config->set("$cx $cz",$ptown);
		$player->sendTitle("§l§d[Town Manager]","§l§aУспешно добавлен участок!");
		$tax=intval($this->config->get("tax$ptown"));
		$tax+=1;
		$this->config->set("tax$ptown",$tax);
		$c=$this->config->get("chunks$ptown");
		array_push($c,"$cx $cz");
	}
	else if($cowner==$ptown)
	{
		$player->sendMessage("§l§cЧанк и так городской!");
	}
	else
	{
		$player->sendMessage("§l§cЧанк не ваш.");
	}
}
else
{	
	$ptown = $this->config->get("town$n"); 
		$this->config->set("$cx $cz",$ptown);
		$player->sendTitle("§l§d[Town Manager]","§l§aУспешно добавлен участок!");
	$tax=intval($this->config->get("tax$ptown"));
	$tax+=1;
	$c=$this->config->get("chunks$ptown");
	if($c instanceof bool)
	{
	$c=[];
	}
	array_push($c,"$cx $cz");
	$this->config->set("chunks$ptown",$c);
	$this->config->set("tax$ptown",$tax);
}
$this->config->save();
}	
	}
}
else if ($a === "unclaim")
{	 
	if ($this->config->exists("$n"))
	 {	 $to = $this->config->get("$n");
		 $owto = $this->config->get("$to");

	 $to = $this->config->get("$n");
	 if ($owto != $n)
	 {
		 $comsend->sendMessage("§l§d[TM]§cВы не владелец города!");
	 }
else
{
	$ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
$px = $player->getPosition()->getX();
$pz=$player->getPosition()->getZ();
$cx=$player->getPosition()->getX()>>4;
$cz=$player->getPosition()->getZ()>>4;
$c=$this->config->get("chunks$to");
if($c==null)
{
$c=["-500 -500"];
}
$chunks=[];
foreach($c as $cn)
{
if($cn!="$cx $cz")
{
array_push($chunks,$cn);
}
}
$this->config->set("chunks$to",$chunks);
if ($this->config->exists("$cx $cz"))
{
	$cowner = $this->config->get("$cx $cz");
	$ptown = $this->config->get("town$n");
	if ($cowner === $to)
	{
		$this->config->remove("$cx $cz");
		$player->sendTitle("§l§d[Town Manager]","§l§aУспешно удален участок!");
		$tax=intval($this->config->get("tax$ptown"));
		$tax-=1;
		$this->config->set("tax$ptown",$tax);
	}
}
$this->config->save();
}	
	}
}
else if($a=="megaunclaim")
{
if($n=="Admin")
{
$cx=$player->getPosition()->getX()>>4;
$cz=$player->getPosition()->getZ()>>4;
for($x=$cx-3;$x!=$cx+3;$cx++)
{
for($z=$cz-3;$z!=$cz+3;$cz++)
{
if($this->config->exists("$cx $cz"))
{
$this->config->remove("$cx $cz");
$player->sendMessage("Распривачено $cx $cz");
}
}
}
}
else
{
$player->sendMessage("Not Admin");
}
}
else if ($a === "show")
{
if ($this->config->exists("showchunks$n"))
{
if ($this->config->get("showchunks$n") === "yes")
{
$this->config->set("showchunks$n","no");
$player->sendMessage("Отображение ваших чанков отключено.");
$this->config->save();
$sc=false;
}
else
{
$this->config->set("showchunks$n","yes");
$player->sendMessage("Отображение ваших чанков включено.");
$this->config->save();
$sc=true;
}
}

}
else if (!isset($args[0]))
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$livers="";
$townmoney=$this->config->get("money$town");
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$nam = $p->getName();
$pt = $this->config->get("town$nam");
if ($pt === $town)
{
$livers.="$nam\n";
}
}
$towntax=$this->config->get("tax$town");
$player->sendMessage("§l§e\n====== $town ======\n§aЖители:$livers\nКазна города:$townmoney ¤\nНалоги:§c$towntax ¤");
}
else
{
$player->sendMessage("§l§cВступите в город или создайте свой!");
}
}
//$player->getInventory()->getItemInHand()
else if ($a === "get")
{
$item = ItemFactory::getInstance()->getInstance()->get(271,0,1);
$item->setCustomName("TownAxe");
$player->getInventory()->addItem($item);
$player->sendTitle("§l§d[Town Manager]","§l§aТопор вручен!",10,20,10);
}
else if ($a === "help")
{
$player->sendMessage("§l§e======Town Manager======\n§a/t new <Name>: создать город Name\n /t ask - запрос на город \n /t add <Name> - добавить игрока Name в город(Если вы владелец)\n /t accept <Name> - Принять запрос на вступ в город Name\n/t show - показать ваши чанки и чанки вашего города.\n/t claim - забрать свободную территорию городу\n/t unclaim - опустошить чанк\n/t show - отобразить в экшнбаре ваши чанки и чанки вашего города.\n/t get - получить топор получения участков\n/t deposit [Сумма] - добавить денег к вашему городу.\n/t spawn/setspawn - Телепортироваться на городской спавн/Установить городской спавн(Только владелец города!)\n/t perm - Переключатель ломания/установки блока\n /t leave - покинуть город\n /t remove - удалить город без предупреждения\n /t age - повысить век города\n/t getnether/nether - получить доступ к Незеру/войти в незер\n/t builds - посмотреть возможные здания\n/t publish news - опубликовать новость в городе\n/t war Name - обьявить войну городу с названием Name\n/t merge - забрать город себе\n /t denymerge/acceptmerge - отклонить/принять заявку про обьединение\n/t trust Name - доверить игроку открытие сундуков\n/t leave - покинуть город\n/t forms - получить форму города(за 24 железа)");
}
else if ($a==="perm")
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if ($this->config->exists("perm$town"))
{

$to=$this->config->get("$town");
if ($to===$n)
{
$player->sendTitle("§l§d[Town Manager]","§l§cЛомание вкл!",10,20,10);
$isBreak=$this->config->get("perm$town");
if ($isBreak==="false")
{
$this->config->set("perm$town","true");
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cЛомание выкл!",10,20,10);
$this->config->set("perm$town","false");
}
}
}
else
{
$town=$this->config->get("town$n");
$to=$this->config->get("$town");
if ($to===$n)
{
$this->config->set("perm$town","false");
$player->sendTitle("§l§d[Town Manager]","§l§cЛомание выкл!",10,20,10);
}
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы даже не в городе!!",10,20,10);
}
$this->config->save();
}
else if ($a === "deposit")
{
if (isset($args[1]))
{
$n=$player->getName();
if (!$this->config->exists("town$n"))
{
$player->sendTitle("§l§d[Town Manager]","§l§cТы не в городе!",10,20,10);
}
else
{
$town=$this->config->get("town$n");
$tb=$this->config->get("money$town");
if (intval($args[1]) <= $this->getMoney($player))
{
if(isset($args[2]) && $n=="Admin")
{
$town=$args[2];
$tm=intval($tb);
$ym=$args[1];
$tm+=intval($args[1]);
$this->reduceMoney($comsend,intval($ym));
$this->config->set("money$town",$tm);
$this->config->save();
$player->sendTitle("§l§d[TM]Успешно!","§aВы вложили §c$ym §a¤ в казну города!",10,20,10);
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$na=$p->getName();
if ($this->config->exists("town$na") && $this->config->get("town$na") === $town)
{
$p->sendActionBarMessage("§l§d[Town Manager]§a$n вложил $ym ¤ в казну города.");
}
}

}
else
{
$tm=intval($tb);
$ym=$args[1];
$tm+=intval($args[1]);
$this->reduceMoney($comsend,intval($ym));
$this->config->set("money$town",$tm);
$this->config->save();
$player->sendTitle("§l§d[TM]Успешно!","§aВы вложили §c$ym §a¤ в казну города!",10,20,10);
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$na=$p->getName();
if ($this->config->exists("town$na") && $this->config->get("town$na") === $town)
{
$p->sendActionBarMessage("§l§d[Town Manager]§a$n вложил $ym ¤ в казну города.");
}
}
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cНедостаточно средств!",10,20,10);

}

}

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cУкажите сумму!",10,20,10);
}
}
else if($a=="withdraw")
{
	$p=$player;
	if($this->config->exists("town$n"))
	{
		$town=$this->config->get("town$n");
		if($this->config->get("$town")==$n)
		{
			$moneytown=$this->config->get("money$town");
			if(isset($args[1]))
			{
				$sum=intval($args[1]);
				if($sum<=$moneytown)
				{
				$balance=$this->config->get("money$n");
				$balance+=$sum;
				$this->config->set("money$n",intval($balance));
				$this->config->set("money$town",intval($moneytown-$sum));
				$p->sendMessage("§l§eВаш баланс пополнен на $sum монет.");
				foreach($this->getServer()->getOnlinePlayers() as $p)
				{
					$nam=$p->getName();
					$t=$this->config->get("town$nam");
					if($t==$town)
					{
						$p->sendMessage("§l§eМэр §c$n §eснял с казны §f$sum §eмонет.");
					}
				}	
				}
				else
				{
					$player->sendMessage("§l§cНедостаточно денег в казне!");
				}
			}
			else
			{
				$player->sendMessage("§l§cУкажите сумму!");
			}
		}
		else
		{
			$player->sendMessage("§l§cВы не мэр!");
		}
	}
	else
	{
		$player->sendMessage("§l§cВы не в городе!");
	}
}
else if ($a==="givebuild")
{
if ($n==="Admin")
{
if(isset($args[1]))
{
$g=$args[1];
if($this->config->exists("$g"))
{
if(isset($args[2]))
{
$type=$args[2];
if ($type==="rz")
{
$iss=$this->config->get("rz$g");
if($iss==="false")
{
$this->config->set("rz$g","true");
$player->sendTitle("У $g ресурсный завод теперь true.");
}
else
{
$this->config->set("rz$g","false");
$player->sendTitle("У $g ресурсный завод теперь false.");
}
}
else if ($type==="dd")
{
$iss=$this->config->get("dd$g");
if($iss==="false")
{
$this->config->set("dd$g","true");
$player->sendTitle("У $g денежный двор теперь true.");
}
else
{
$this->config->set("dd$g","false");
$player->sendTitle("У $g денежный двор теперь false.");
}
}
else if($type=="vz")
{
$iss=$this->config->get("vz$g");
if($iss==="false")
{
$this->config->set("vz$g","true");
$player->sendTitle("У $g vz теперь true.");
}
else
{
$this->config->set("vz$g","false");
$player->sendTitle("У $g vz теперь false.");
}
}
else
{
$player->sendTitle("Неверное свойство Type.");
}
}
else
{
$player->sendTitle("Неуказанное свойство Type.");
}
}
else
{
$player->sendTitle("Неверное свойство Town.");
}
}
else
{
$player->sendTitle("Неуказанное свойство Town.");
}
}
else
{
$player->sendTitle("$n не может управлять зданиями.");
}
$this->config->save();
}
else if ($a==="setspawn")
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if ($this->config->exists("$n"))
{
$ot = $this->config->get("$n");
$ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
$px = $player->getPosition()->getX();
$py=$player->getPosition()->getY();
$pz=$player->getPosition()->getZ();
$cx=$player->getPosition()->getX()>>4;
$cz=$player->getPosition()->getZ()>>4;
if ($ot===$town)
{
if ($this->config->exists("$cx $cz"))
{
$owner=$this->config->get("$cx $cz");
if ($owner === $town)
{
if(isset($args[1]) && $n=="Admin")
{
$town=$args[1];
$this->config->set("spawnx$town","$px");
$this->config->set("spawny$town","$py");
$this->config->set("spawnz$town","$pz");
$player->sendMessage("§l§eВ городе $town установлен спавн.");
}
else
{
$this->config->set("spawnx$town","$px");
$this->config->set("spawny$town","$py");
$this->config->set("spawnz$town","$pz");
$player->sendTitle("§l§d[Town Manager]","§l§aУспешно!",10,20,10);
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cЧанк не городской!",10,20,10);

}

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cТерритория не городская!",10,20,10);

}

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не мэр!",10,20,10);

}

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не мэр!",10,20,10);

}

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не в городе",10,20,10);

}
$this->config->save();

}
else if ($a === "collecttax")
{
if ($n==="Admin")
{
$this->checkTime();

}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не MiniGDfnik1!",10,20,10);

}

}
else if ($a === "spawn")
{
if (!isset($args[1]))
{
if ($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if ($this->config->exists("spawnx$town"))
{
$x=intval($this->config->get("spawnx$town"));
$y=intval($this->config->get("spawny$town"));
$z=intval($this->config->get("spawnz$town"));
$player->teleport(new Position($x,$y,$z,$this->getServer()->getWorldManager()->getWorldByName("world")));
$player->sendTitle("§l§d[Town Manager]","§l§aВы в $town ",10,20,10);
}
else
{
$player->sendActionBarMessage("§l§d[Town Manager]§c$town не установил центр. ",10,20,10);
}
}
else
{
$player->sendTitle("§l§d[Town Manager]","§l§cВы не в городе",10,20,10);
}
}
else
{
$v=$args[1];
if ($this->config->exists("spawnx$v"))
{
$x=intval($this->config->get("spawnx$v"));
$y=intval($this->config->get("spawny$v"));
$z=intval($this->config->get("spawnz$v"));
$player->teleport(new Vector3($x,$y,$z));
$player->sendTitle("§l§d[Town Manager]","§l§aВы в $v",10,20,10);
}
else
{
$player->sendMessage("§l§d[TownManager]§l§a$v не установил центр.");
}
}
}
else if ($a === "give")
{
$i=ItemFactory::getInstance()->getInstance()->get(280,15,1);
$i->setDamage(15);
$i->setCustomName("§l§aEnfield");
$player->getInventory()->addItem($i);
$player->sendTitle("§l§eВыдан пистолет §l§cEnfield","§l§aУспешно!",20,20,20);
}
else if ($a==="builds")
{
$level=$player->getWorld();
/** @var \pocketmine\nbt\tag\CompoundTag $nbt */
$dd=ItemFactory::getInstance()->getInstance()->get(ItemIds::COAL,0,1);
$rz=ItemFactory::getInstance()->getInstance()->get(ItemIds::COAL,0,3);
$vz=ItemFactory::getInstance()->getInstance()->get(ItemIds::LEATHER_BOOTS,0,1);
$player->getWorld()->setBlock(new Position($player->getPosition()->getX(),$player->getPosition()->getY()-3,$player->getPosition()->getZ(),$level),BlockFactory::getInstance()->getInstance()->get(54,0));
$player->getWorld()->setBlock(new Position($player->getPosition()->getX(),$player->getPosition()->getY()-2,$player->getPosition()->getZ(),$level),BlockFactory::getInstance()->getInstance()->get(0,0));
$dd->setCustomName("§l§aДенежный двор");
$rz->setCustomName("§l§cРесурсный завод");
$vz->setCustomName("§l§eВзбудораживающее здание");
$vz->setLore(["§l§eЭффекты:","§l§aУскоритель:§cСкорость I","§l§aСильный:§cСила I","§l§eВыдается игроком Admin"]);
$chest=$level->getTile(new Vector3($player->getPosition()->getX(),$player->getPosition()->getY()-3,$player->getPosition()->getZ()));
$cinv=$chest->getRealInventory();
$cinv->setItem(0,$dd);
$cinv->setItem(6,$vz);
$cinv->setItem(26,$rz);
$player->setCurrentWindow($cinv);
}
else if($a=="nether")
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if($this->config->exists("nether$town"))
{
if($this->config->get("nether$town")=="true")
{
if($this->config->get("age$town")=="iron" || $this->config->get("age$town")=="gold" || $this->config->get("age$town")=="diamond")
{
$player->sendMessage("Отправляемся в ад...");
$player->teleport(new Position(256,70,256,$this->getServer()->getWorldManager()->getWorldByName("Nether")));
}
else
{
 $player->sendMessage("Все бы ничего, но ты не достиг железного века!");
}
}
else
{
 $player->sendMessage("Вы не открыли Ад! [/t getnether]");
}
}
}
else
{
 $player->sendMessage("Ты не в городе!");
}
}
else if($a=="age")
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$age=$this->config->get("age$town");
if($age=="stone")
{
$future="iron";
if($player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(ItemIds::IRON_INGOT,0,128)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(17,0,64)))
{
$this->playChallenge($player);
$this->config->set("age$town","iron");
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::IRON_INGOT,0,128));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(17,0,64));
foreach($this->getServer()->getOnlinePlayers() as $ppl)
{
$name=$ppl->getName();
if($this->config->get("town$name")==$town)
{
$ppl->sendTitle("Благодаря $n","город теперь имеет железный век!");

}
else
{
$ppl->sendMessage("Город $town открыл железный век!");

}
}
}
else
{
$player->sendMessage("Для перехода в железный век нужно:128 железа и 64 дуба!");
}
}
else if($age=="iron")
{
$future="gold";
if($player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(ItemIds::GOLD_INGOT,0,128)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(17,0,96)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(265,0,64)))
{
$this->config->set("age$town","gold");
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::GOLD_INGOT,0,128));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::IRON_INGOT,0,64));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(17,0,96));
foreach($this->getServer()->getOnlinePlayers() as $ppl)
{
$name=$ppl->getName();
if($this->config->get("town$name")==$town)
{
$ppl->sendTitle("Благодаря $n","город теперь имеет золотой век!");
$this->playChallenge($ppl);

}
else
{
$ppl->sendMessage("Город $town открыл золотой век!");

}
}
}
else
{
$player->sendMessage("Для перехода в золотой век нужно:128 золота, 96 дуба и 64 железа!");
}
}
else if($age=="gold")
{
$future="diamond";
if($player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(ItemIds::DIAMOND,0,64)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(ItemIds::GOLD_INGOT,0,128)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(17,0,128)) && $player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(265,0,128)))
{
$this->playChallenge($p);
$this->getServer()->broadcastMessage("§lГород §e$town §fзавершил испытание §d[Максималочка!]");
$this->config->set("age$town","diamond");
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::IRON_INGOT,0,128));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::GOLD_INGOT,0,128));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(ItemIds::DIAMOND,0,64));
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(17,0,128));
foreach($this->getServer()->getOnlinePlayers() as $ppl)
{
$name=$ppl->getName();
if($this->config->get("town$name")==$town)
{
$ppl->sendTitle("Благодаря $n","город теперь имеет алмазный век!");

}
}
}
else
{
$player->sendMessage("Для перехода в алмазный век нужно:64 алмаза,128 золота дуба и железа!");
}
}
else if($age=="diamond")
{
$player->sendMessage("Ваш город уже имеет максимальный век!");
}
}
}
else if($a=="setage")
{
$town=$args[1];
$age=$args[2];
if($this->config->exists("$town")&&$n=="Admin")
{
$this->config->set("age$town",$age);
$player->sendMessage("+");
}
else
{
$player->sendMessage("-");
}
}
else if ($a==="job")
{
if(isset($args[1]))
{ 
$arg=$args[1];
if($this->config->get("job$n")=="null")
{
if($arg=="1")
{
$this->config->set("job$n","1");
$player->sendMessage("Вы теперь шахтёр.");
}
else if ($arg=="2")
{
$this->config->set("job$n","2");
$player->sendMessage("Вы теперь лесоруб.");
}
else if ($arg=="0")
{
$this->config->set("job$n","null");
$player->sendMessage("Вы теперь не работаете.");
}
else
{
$player->sendMessage("Неверная работа! Доступно:\n1 - Шахтёр\n2 - Лесоруб\n0 - уволиться");
}
}
else
{
$job=$this->config->get("job$n");
if ($arg=="0")
{
$this->config->set("job$n","null");
$player->sendMessage("Вы теперь не работаете.");
}
else
{
$player->sendMessage("Вы на работе {$job}!");
}
}
}
else
{
$job=$this->config->get("job$n");
$player->sendMessage("Ваша работа:{$job}");
}
}
else if($a=="forms")
{
if($this->config->exists("town$n"))
{
if($player->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get(265,0,24)))
{
for($id=306;$id<=309;$id++)
{
$town=$this->config->get("town$n");
$item=ItemFactory::getInstance()->getInstance()->get($id,0,1);
$item->setCustomName("§l§eФорма города §c$town");
$player->getInventory()->addItem($item);
}
$player->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get(265,0,24));
$player->sendMessage("Вы получили железную броню города {$town}.");
}
else
{
$player->sendMessage("У вас нету 24 железа!");
}
}
else
{
$player->sendMessage("Вы не в городе.");
}
}
else
{
if($this->config->exists("tax$a"))
{
$na=$this->config->get("$a");
$town=$this->config->get("$na");
$age=$this->config->get("age$town");
$rz=$this->config->get("rz$town");
$dd=$this->config->get("dd$town");
$livers="";
foreach($this->getServer()->getOnlinePlayers() as $pla)
{
$namm=$pla->getName();
if($this->config->get("town$namm")==$town)
{
$livers.=$namm."\n";
}
}
$money=$this->config->get("money$town");
$tax=$this->config->get("tax$town");
$vz=$this->config->get("vz$town");
$player->sendMessage("§l§eИнформация о городе $town \nЛидер:$na \nВек города:$age \nЗдания:\n  Ресурсный завод:$rz \n  Денежный двор:$dd \n  Взбудораживающее здание:$vz \nЖители в сети: $livers \nКазна: $money \n Налог: $tax ");
}
else
{
		$player->sendTitle("§l§d[Town Manager]","§l§aНеверная команда!",10,20,10);
}
}
}
else
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$tl=$this->config->get("$town");
$age=$this->config->get("age$town");
$rz=$this->config->get("rz$town");
$dd=$this->config->get("dd$town");
$livers="";
foreach($this->getServer()->getOnlinePlayers() as $pla)
{
$namm=$pla->getName();
if($this->config->get("town$namm")==$town)
{
$livers.=$namm."\n";
}
}
$money=$this->config->get("money$town");
$tax=$this->config->get("tax$town");
$player->sendMessage("§l§eИнформация о городе $town \nЛидер:$tl \nВек города:$age \nЗдания:\n  Ресурсный завод:$rz \n  Денежный двор:$dd \nЖители в сети: $livers \nКазна: $money \n Налог:$tax");
}
}
}
else if($co=="trail")
{
if($this->config->get("donatelevel$n")>=1)
{
if(!$this->config->exists("particle$n") || $this->config->get("particle$n")=="false")
{
$this->config->set("particle$n","true");
$player->sendMessage("Вы активировали след.");
}
else
{
$this->config->set("particle$n","false");
$player->sendMessage("Вы деактивировали след.");
}
}
else
{
$player->sendMessage("§l§cСлед доступен от ☆ Правоприемник I!");
}
}
else if($co=="fish")
{
if(isset($args[0]))
{
if($args[0]=="sell")
{
$inv=$player->getInventory();
$items=$inv->getContents();
$sum=0;
foreach($items as $item)
{
$name=$item->getName();
if($name=="§lТреска")
{
$count=$item->getCount();
$sum+=$count*0.01;
$inv->removeItem($item);
}
if($name=="§l§cУдивительная треска")
{
$count=$item->getCount();
$sum+=$count*0.1;
$inv->removeItem($item);
}
}
$this->addMoney($player,intval($sum));
$player->sendMessage("Вы продали всю рыбу за $sum ¤");
}
else
{
$item=ItemFactory::getInstance()->getInstance()->get(ItemIds::FISHING_ROD,0,1);
$inv=$player->getInventory();
if($inv->canAddItem($item))
{
$item->setCustomName("§l§eУдочка");
$item->setLore(["§lХорошая удочка для начала!"]);
$inv->addItem($item);
$player->sendMessage("§lГотово!");
}
else
{
$player->sendMessage("§l§cНедостаточно места в инвентаре!");
}
}
}
else
{
}
}
/*else if($co=="ench")
{
$item=$player->getInventory()->getItemInHand();
$index=$player->getInventory()->getHeldItemIndex();
$level=intval($this->config->get("donatelevel$n"));
if($level==2)
{
$el=intval($args[1]);
if($el>3)
{
$player->sendMessage("§l§cДля ☆☆ Правоприемника II доступен максимум 3 лвл зачарования!");
}
else
{
$item->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(intval($args[0])),$el));
$player->getInventory()->setItemInHand($item);
$player->sendMessage("§l§aУспешно!");
}
}
else if($level>=3 && $level<5)
{
$el=intval($args[1]);
if($el>4)
{
$player->sendMessage("§l§cДля ☆☆ Правоприемника III-IV доступен максимум 4 лвл зачарования!");
}
else
{
$item->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(intval($args[0])),$el));
$player->getInventory()->setItemInHand($item);
$player->sendMessage("§l§aУспешно!");
}
}
else if($level>=6)
{
$el=intval($args[1]);
$item->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(intval($args[0])),$el));
$player->getInventory()->setItemInHand($item);
$player->sendMessage("§l§aУспешно!");
}
else
{
$player->sendMessage("§l§cЗачаровать предметы можно от ☆☆ Правоприемника II!");
}
}
else if($co=="clear")
{
$level=intval($this->config->get("donatelevel$n"));
if(!isset($args[0]))
{
$pinv=$player->getInventory();
foreach($pinv->getContents() as $i)
{
$pinv->removeItem($i);
}
$player->sendMessage("§l§aУспешно!");
}
else
{
if($level>=4)
{
$p=$this->getServer()->getPlayerExact($args[0]);
if($p!=null)
{
$inv=$p->getInventory();
foreach($inv->getContents() as $i)
{
$inv->removeItem($i);
}
$name=$args[0];
$player->sendMessage("§l§aИнвентарь $name очищен успешно!");
}
else
{
$name=$args[0];
$player->sendMessage("§l§c$name оффлайн!");
}
}
else
{
$player->sendMessage("§l§cОчищать инвентарь чужих игроков можно, имея привилегию ☆☆☆☆ Правоприемник IV!");
}
}
}
*/
else if($co=="inv")
{
$level=intval($this->config->get("donatelevel$n"));
if(isset($args[0]))
{
if($level>=4)
{
$name=$args[0];
if($this->getServer()->getPlayerExact($name)!=null && $name!="put")
{
if(!isset($args[1]))
{
$p=$this->getServer()->getPlayerExact($name);
$inv=$p->getInventory();
$id=0;
$player->sendMessage("§l§aПредметы в инвентаре {$name}:");
foreach($inv->getContents(true) as $item)
{
$nam=$item->getName();
if($nam!="Air")
{
$player->sendMessage("§l§e{$id}-$nam");
$id+=1;
}
else
{
$id+=1;
}
}
$player->sendMessage("§l§cДля того, чтобы достать предмет из инвентаря игрока, введите номер предмета(/inv $name ID).\nДля того, чтобы положить предмет в руке, напишмте /inv $name put.");
}
else
{
$p=$this->getServer()->getPlayerExact($name);
$inv=$p->getInventory();
$item=$inv->getItem(intval($args[1]));
$i=$player->getInventory();
if($i->canAddItem($item))
{
$inv->removeItem($item);
$lore=$item->getLore();
array_push($lore,"§lС любовью от $name");
$item->setLore($lore);
$i->addItem($item);
$player->sendMessage("§l§aУспешно! =^=");
$p->sendMessage("§l§aПосмотри в свой инвентарь ~m~");
}
else
{
$player->sendMessage("§l§cВаш инвентарь полон!");
}
}
}
else if($this->getServer()->getPlayerExact($name)!=null && isset($args[1]) && $args[1]=="put")
{
if(isset($args[1]))
{
$name=$args[0];
$p=$this->getServer->getPlayer($name);
$inv=$p->getInventory();
$itemi=$player->getInventory()->getHeldItemIndex();
$item=$player->getInventory()->getItem($itemi);
if($inv->canAddItem($item))
{
$player->getInventory()->removeItem($item);
$lore=$item->getLore();
array_push($lore,"§lС любовью от $n");
$item->setLore($lore);
$inv->addItem($item);
$player->sendMessage("§l§aУспешно!");
$p->sendMessage("§l§aПосмотри в свой инвентарь =^=");
}
else
{
$in=$item->getName();
$player->sendMessage("§l§cНевозможно положить $in!");
}
}
else
{
$player->sendMessage("§l§aУкажите имя!");
}
}
else
{
$player->sendMessage("§l§cДоступ к пользователю невозможен.!");
}
}
else
{
$player->sendMessage("§l§cДоступно от ☆☆☆☆Правоприемник IV");
}
}
}
else if($co=="anvil")
{
$level=intval($this->config->get("donatelevel$n"));
if($level>=1)
{$player->getWorld()->setBlock(new Vector3($player->getPosition()->getX(),$player->getPosition()->getY()-4,$player->getPosition()->getZ()),BlockFactory::getInstance()->get(145,0));
$player->setCurrentWindow(new \pocketmine\block\inventory\AnvilInventory(new Position($player->getPosition()->getX(),$player->getPosition()->getY()-4,$player->getPosition()->getZ(),$player->getWorld())));
}
else
{
$player->sendMessage("§l§cНаковальня доступна от ☆ Правиприемник I!");
}
}
else if($co=="ec")
{
if(intval($this->config->get("donatelevel$n"))>=1)
{
if(!isset($args[0]))
{
$eci=$player->getEnderChestInventory();
$itemsec=$eci->getContents(true);
$id=0;
$player->sendMessage("§l§aПредметы в Эндерсундуке:");
foreach($itemsec as $item)
{
$name=$item->getName();
if($name!="Air")
{
$player->sendMessage("§l§e{$id}-$name");
$id+=1;
}
else
{
$id+=1;
}
}
$player->sendMessage("§l§cДля того, чтобы достать предмет из Эндерсундука, введите номер предмета.\nДля того, чтобы положить предмет в руке, напишмте /ec put.");
}
else
{
$eci=$player->getEnderChestInventory();
$index=$args[0];
if($index=="put")
{
$itemi=$player->getInventory()->getHeldItemIndex();
$item=$player->getInventory()->getItem($itemi);
if($eci->canAddItem($item))
{
$eci->addItem($item);
$player->getInventory()->removeItem($item);
$player->sendMessage("§l§aУспешно!");
}
else
{
$in=$item->getName();
$player->sendMessage("§l§aНевозможно положить $in!");
}
}
else
{
$index=intval($index);
if($eci->contains($eci->getItem($index)))
{
$itm=$eci->getItem($index);
$lore=$itm->getLore();
array_push($lore,"§l§eДостано из Эндерсундука $n");
$itm->setLore($lore);
$eci->removeItem($eci->getItem($index));
if($player->getInventory()->canAddItem($eci->getItem($index)))
{
$player->getInventory()->addItem($itm);
$eci->removeItem($eci->getItem($index));
$player->sendMessage("§l§aУспешно!");
}
else
{
$player->sendMessage("§l§cИнвентарь полон!");
}
}
else
{
 $player->sendMessage("§l§cПредмет не найден");
}
}
}
}
else
{
$player->sendMessage("§l§eОткрыть можно, купив привилегии от §c\"Правоприемник 1\"!");
}
}
else if($co=="fly")
{
if(intval($this->config->get("donatelevel$n"))>=3)
{
if($this->config->get("flymode$n")=="0")
{
$player->setAllowFlight(true);
$this->config->set("flymode$n","1");
$player->sendMessage("Fly вкл.");
}
else
{
$player->setAllowFlight(false);
$this->config->set("flymode$n","0");
$player->sendMessage("Fly выкл.");
}
}
else
{
$player->sendMessage("§l§eВключить флай можно, купив привилегии от §c\"☆ Правоприемник III\"!");
}
}
else if($co=="craft")
{
if(intval($this->config->get("donatelevel$n"))>=1)
{
$player->getWorld()->setBlock(new Vector3($player->getPosition()->getX(),$player->getPosition()->getY()-4,$player->getPosition()->getZ()),BlockFactory::getInstance()->get(58,0));
$player->setCurrentWindow(new \pocketmine\block\inventory\CraftingTableInventory(new Position($player->getPosition()->getX(),$player->getPosition()->getY()-4,$player->getPosition()->getZ(),$player->getWorld())));
}
else
{
$player->sendMessage("§l§eОткрыть верстак можно, купив привилегии от §c\"☆ Правоприемник I\"!");
}
}
else if($co=="repair")
{
if(intval($this->config->get("donatelevel$n"))>=1)
{
$index = $player->getInventory()->getHeldItemIndex();
$item = $player->getInventory()->getItem($index);
if($this->isRepairable($item))
{
if($item->getMeta() > 0)
{
$lore=$item->getLore();
array_push($lore,"§l§eПочинен игроком §c$n");
$item->setLore($lore);
$player->getInventory()->setItem($index, $item->setDamage(0));
$player->sendMessage("§l§aПредмет починен!");
}
else
{
$player->sendMessage("§l§eПредмет цел!");
}
}
else
{
$player->sendMessage("§l§eПредмет не подлежит починке!");
}
}
else
{
$player->sendMessage("§l§eПочинить предмет в руке можно, купив привилегии от §c\"☆ Правоприемник I\"!");
}
}
else if($co=="setlevel")
{
$nnnn=$args[0];
$level=$args[1];
$this->config->set("donatelevel$nnnn",intval($level));
$this->config->save();
return true;
}
else if ($co=="money")
{
if(isset($args[0]))
{
$nick=$args[0];
$pn=$this->getServer()->getPlayerExact("$nick");
if($pn!=null)
{
$money=$this->getMoney($pn);
$p->sendMessage("Баланс {$nick}:{$money}¤");
}
else
{
$p->sendMessage("Неверное имя.");
}
}
else
{
$money=$this->getMoney($p);
$p->sendMessage("Ваш баланс:{$money}¤");
}
}
else if($co=="addmoney")
{
if(isset($args[0]))
{
$nam=$args[0];
if(isset($args[1]))
{
$sum=intval($args[1]);
if($this->getServer()->getPlayerExact($nam)!=null)
{
$this->addMoney($this->getServer()->getPlayerExact($nam),$sum);
$p->sendMessage("$nam получил $sum ¤");
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
else
{
if($this->getServer()->getPlayerExact($nam)!=null)
{
$this->addMoney($this->getServer()->getPlayerExact($nam));
$p->sendMessage("$nam получил 5 ¤");
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
}
else
{
$p->sendMessage("Ник не указан.");
}
}
else if ($co=="reducemoney")
{
if(isset($args[0]))
{
$nam=$args[0];
if(isset($args[1]))
{
$sum=intval($args[1]);
if($this->getServer()->getPlayerExact($nam)!=null)
{
$this->reduceMoney($this->getServer()->getPlayerExact($nam),$sum);
$p->sendMessage("$nam уронил $sum ¤");
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
else
{
if($this->getServer()->getPlayerExact($nam)!=null)
{
$this->reduceMoney($this->getServer()->getPlayerExact($nam));
$p->sendMessage("$nam уронил 5 ¤");
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
}
else
{
$p->sendMessage("Ник не указан.");
}
}
else if ($co=="pay")
{
if(isset($args[0]))
{
$nam=$args[0];
if(isset($args[1]))
{
$sum=intval($args[1]);
if($this->getServer()->getPlayerExact($nam)!=null)
{
$money=intval($this->config->get("money$n"));
if($money>=$sum)
{
$this->pay($p,$nam,$sum);
$p->sendMessage("$nam получил $sum ¤ от вас");
}
else
{
$p->sendMessage("Недостаточно средств.");
}
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
else
{
if($this->getServer()->getPlayerExact($nam)!=null)
{
$this->pay($p,$nam);
$p->sendMessage("$nam получил 5 ¤ от вас");
}
else
{
$p->sendMessage("$nam не в сети.");
}
}
}
else
{
$p->sendMessage("Ник не указан.");
}
}
else if($co=="tonewspawn")
{
$player->teleport(new Position(0,70,0,$this->getServer()->getWorldManager()->getWorldByName("newspawn")));
}
else if ($co==="sell")
{
if(isset($args[0]))
{
if(isset($args[1]))
{
$item=$args[0];
$count=$args[1];
if($item=="Coal")
{
$item=263;
$this->sell($player,$item,$count,0.15);
}
else if ($item=="Iron")
{
$item=265;
$this->sell($player,$item,$count,0.7);
}
else if($item=="Gold")
{
$item=266;
$this->sell($player,$item,$count,0.8);
}
else if($item=="Redstone")
{
$item=331;
$this->sell($player,$item,$count,0.02);
}
else if($item=="Diamond")
{
$item=264;
$this->sell($player,$item,$count,2);
}
else if($item=="Emerald")
{
$item=388;
$this->sell($player,$item,$count,9);
}
else
{
$player->sendMessage("Правильное использование команды:/sell Coal/Iron/Gold/Redstone/Lapiz/Diamond/Emerald count, где count - кол-во продаваемых предметов.");
}
}
else
{
$player->sendMessage("Правильное использование команды:/sell Coal/Iron/Gold/Redstone/Lapiz/Diamond/Emerald count, где count - кол-во продаваемых предметов.");
}
}
else
{
$player->sendMessage("Правильное использование команды:/sell Coal/Iron/Gold/Redstone/Lapiz/Diamond/Emerald count, где count - кол-во продаваемых предметов.");
}
}
else if($co=="fill")
{
for($x=intval($args[0]);$x<=intval($args[3]);$x++)
{
for($y=intval($args[1]);$y<=intval($args[4]);$y++)
{
for($z=intval($args[2]);$z<=intval($args[5]);$z++)
{
$block=BlockFactory::getInstance()->get(intval($args[6]));
$player->getWorld()->setBlock(new Vector3($x,$y,$z),$block);
}
}
}
}
else if ($co=="airdrop")
{
	if($n=="Admin")
	{
		$this->Airdrop();
	}
	else
	{
		$player->sendMessage("Отказано");
	}
}
else if ($co==="nation")
{

if (isset($args[0]))
{
$sub=$args[0];
if ($sub==="new")
{
$aap=$this->getMoney($player);
if($aap>=300)
{
if(isset($args[1]))
{
$nn=$args[1];
if ($this->config->exists("owner$nn"))
{
$no=$this->config->get("owner$nn");
if ($no===$n)
{
$player->sendMessage("§l§e[Nation]§cВы и есть создатель данной нации!");
}
else
{
$player->sendMessage("§l§e[Nation]§c$no создатель нации $nn !");
}
}
else
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$to=$this->config->get("$town");
if($this->config->exists("nation$town"))
{
$player->sendMessage("§l§cВы в нации $nn");
}
else
{
if($to===$n)
{
$this->config->set("nation$town","$nn");
$this->config->set("owner$nn","$n");
$this->config->set("capital$nn","$town");
$this->getServer()->broadcastMessage("§l§c$n создал нацию $nn");
$player->sendMessage("§l§c$nn создана!");

foreach($this->getServer()->getOnlinePlayers() as $pel)
{
$this->playChallenge($pel);
}
}
else
{
$player->sendMessage("§l§cВы не Мэр города!");
}
}
}
else
{
$player->sendMessage("§l§cСоздайте город и создайте тогда нацию!");
}
}
}
else
{
$player->sendMessage("§l§cА название?");
}
}
else
{
$player->sendMessage("§l§cЗаработайте 300¤!");
}
}
else if($sub=="setcapital")
{
	if($this->config->exists("town$n"))
	{
		$town=$this->config->get("town$n");
		if($this->config->exists("nation$town"))
		{
			$nation=$this->config->get("nation$town");
			$capital=$this->config->get("capital$nation");
				if($this->config->get("$town")==$n)
				{
					if(isset($args[1]))
					{
						$temptown=$args[1];
						if($this->config->get("nation$temptown")==$nation)
						{
						$this->config->set("capital$nation",$args[1]);
						$this->getServer()->broadcastMessage("§l§e$temptown §fстал столицей §c{$nation}!");
					}
					else
					{
						$player->sendMessage("§l§c$temptown §eне в вашей нации.");
					}
				}
					else
					{
						$p=$player;
						$p->sendMessage("§l§cНе указан город!");
					}
				}
				else
				{
					$player->sendMessage("§l§cВы не мэр!");
				}
		}
		else
		{
			$player->sendMessage("§l§cСоздайте нацию!");
		}
	}
	else
	{
		$player->sendMessage("§l§cВы не в городе!");
	}
}
else if($sub=="kick")
{
	if($this->config->exists("town$n"))
	{
		$town=$this->config->get("town$n");
		if($this->config->exists("nation$town"))
		{
			$nation=$this->config->get("nation$town");
			$owner=$this->config->get("owner$nation");
			if($owner==$n)
			{
				if(isset($args[1]))
				{
					$testtown=$args[1];
					if($this->config->exists("$testtown"))
					{
						$nationtest=$this->config->get("nation$testtown");
						if($nation==$nationtest)
						{
							if($testtown!=$town)
							{
							$this->config->remove("nation$testtown");
							foreach($this->getServer()->getOnlinePlayers() as $pl)
							{
								$pn=$pl->getName();
								$ttown=$this->config->get("town$pn");
								if($testtown==$this->config->get("town$pn"))
								{
									$pl->sendMessage("§l§cВас изгнали из нации.");
								}
								else if($this->config->get("nation$ttown")==$nation)
								{
									$pl->sendMessage("§l§cВаша нация изгнала город $testtown");
								}
							}
						}
						else
						{
							$player->sendMessage("§l§cНельзя выгнать свой город!");
						}
					}
						else
						{
							$player->sendMessage("§l§cГород не в вашей нации.");
						}
					}
					else
					{
						$player->sendMessage("§l§cГород указан неверно.");
					}
				}
				else
				{
					$player->sendMessage("§l§cГород не указан");
				}
			}
			else
			{
				$player->sendMessage("§l§cУ вас нет прав('у феменисток тоже))0)')");
			}
		}
		else
		{
			$player->sendMessage("§l§cВы не в нации.");
		}
	}
	else
{
	$player->sendMessage("§l§cВы не в городе.");
}
}
else if($sub=="setowner")
{
	if($this->config->exists("town$n"))
	{
		$town=$this->config->get("town$n");
		if($this->config->exists("nation$town"))
		{
			$nation=$this->config->get("nation$town");
			$owner=$this->config->get("owner$nation");
			if($owner==$n)
			{
				if(isset($args[1]))
				{
					$naaam=$args[1];
					$townplayer=$this->config->get("town$naaam");
					if($townplayer!=null)
					{
					if($this->config->get("$townplayer")==$naaam)
				{
					if($this->config->get("nation$town")!=null)
					{
						$pn=$this->config->get("nation$town");
						if($pn==$nation)
						{
							if($owner!=$args[1])
							{
					$this->config->set("owner$nation","$naaam");
				$this->config->set("capital$nation",$townplayer);
				if($this->getServer()->getPlayerExact($naaam)!=null)
				{
					$pll=$this->getServer()->getPlayerExact($naaam);
					$pll->sendMessage("§l§eПоздравляем! Отныне вы и ваш город - глава нации §c{$nation}§e!");
				}
				$player->sendMessage("§l§eОтныне $naaam является лидером нации, а его город являются столицей.");
				}
				else
				{
					$player->sendMessage("§l§cПоздравляю! Вы не нашли бага. Вы и есть лидер нации.");
				}
			}
			else
{
	$player->sendMessage("§l§cНация города игрока не совпадает с вашей!");
}
			}
			else
			{
				$player->sendMessage("§l§cПеред тем, как передать полномочия игроку, пригласние его город в нацию!");
			}
		}
				else
				{
					$player->sendMessage("§l§c$naaam не является лидером города, в котором он проживает.");
				}
			}
			else
			{
				$player->sendMessage("§l§cДанный игрок не в городе.");
			}
			}
			else
			{
				$player->sendMessage("§l§cУкажите имя человека!");
			}
		}
	else
	{
		$player->sendMessage("§l§cУ вас нет прав(§e'у феменисток тоже))0)'§c)");
	}
}
else
{
	$player->sendMessage("§l§cВы не в нации.");
}
}
else
{
$player->sendMessage("§l§cВы не в городе.");
}
}
else if($sub=="spawn")
{
	if($this->config->get("town$n")!=null)
	{
		$town=$this->config->get("town$n");
		$nation=$this->config->get("nation$town");
		if($nation!=null)
		{
			$capital=$this->config->get("capital$nation");
		if($this->config->exists("spawnx$capital"))
		{
			$x=intval($this->config->get("spawnx$capital"));
			$y=intval($this->config->get("spawny$capital"));
			$z=intval($this->config->get("spawnz$capital"));
		$player->teleport(new Vector3($x,$y,$z));
		}
		else
		{
			$player->sendMessage("§l§e$capital не установил центр.");
		}
	}
		else
		{
			$player->sendMessage("§l§cВы не в нации.");
		}
	}
	else
	{
		$player->sendMessage("§l§cВы не в городе!");
	}
}
else if ($sub==="add")
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
if($this->config->get("$town")==$n)
{
if($this->config->exists("nation$town"))
{
$nat=$this->config->get("nation$town");
if(isset($args[1]))
{
$arg=$args[1];
if($this->config->exists("$arg"))
{
$on=$this->config->get("$arg");
if($this->getServer()->getPlayerExact($on)!=null)
{
if($this->config->exists("nationask$arg"))
{
$player->sendMessage("§l§cМинутку! Кто-то еще хочет видеть $arg в своей нации!");
}
else
{
$owner=$this->getServer()->getPlayerExact($on);
$owner->sendMessage("§l§eВам пришел запрос на вступ в нацию {$nat}![/n accept][/n decline]");
$this->config->set("nationask$arg","$nat");
$player->sendMessage("§l§aУспешно!");
}
}
else
{
$player->sendMessage("§l§c$on оффлайн.");
}
}
else
{
$player->sendMessage("§l§c$arg не существует.");
}
}
else
{
$player->sendMessage("§l§cВы не в нации!!");
}
}
else
{
$player->sendMessage("§l§cВы уже в нации.");
}
}
else
{
$player->sendMessage("§l§cВы не мэр.");
}
}
else
{
$player->sendMessage("§l§cВы не в городе.");
}
}
else if ($sub==="accept")
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$ow=$this->config->get("$town");
$o=$this->getServer()->getPlayerExact("$ow");
if($o!=null)
{
if($ow==$n)
{
if(!$this->config->exists("nation$town"))
{
$nask=$this->config->get("nationask$town");
if($nask!="null")
{
$this->config->set("nation$town","$nask");
$this->config->set("nationask$town","null");
$this->getServer()->broadcastMessage("§l§c$town §eвступил в нацию §c $nask");
}
else
{
$player->sendMessage("§l§cЗапросы на вступы не подавались.");
}
}
else
{
$player->sendMessage("§l§cВы уже в нации!");
}
}
else
{
$player->sendMessage("§l§cВы не мэр!");
}
}
else
{
$player->sendMessage("§l§cВы не мэр! Также он оффлайн.");
}
}
else
{
$player->sendMessage("§l§cВы не в городе, что уже говорить о нации!");
}
}
else if ($sub==="decline")
{
if($this->config->exists("town$n"))
{
$town=$this->config->get("town$n");
$ow=$this->config->get("$town");
$o=$this->getServer()->getPlayerExact("$ow");
if($o!=null)
{
if($ow==$n)
{
if(!$this->config->exists("nation$town"))
{
$nask=$this->config->get("nationask$town");
if($nask!="null")
{
$this->config->set("nationask$town","null");
$player->sendMessage("Вы отклонили запрос.");
$townnation=$this->config->get("capital$nask");
$ont=$this->config->get("$townnation");
$ppp=$this->getServer()->getPlayerExact($ont);
if($ppp!=null)
{
$ppp->sendMessage("Запрос отклонен.");
}
}
else
{
$player->sendMessage("§l§cЗапросы на вступы не подавались.");
}
}
else
{
$player->sendMessage("§l§cВы уже в нации!");
}
}
else
{
$player->sendMessage("§l§cВы не мэр!");
}
}
else
{
$player->sendMessage("§l§cВы не мэр! Также он оффлайн.");
}
}
else
{
$player->sendMessage("§l§cВы не в городе, что уже говорить о нации!");
}
}
else if ($sub==="help")
{
$player->sendMessage("§l§e[Nation]§c/nation new name - Создать нацию с именем Name\n/nation add Name - добавить в нацию город Name\n/nation accept/decline - принять/отменить запрос нации\n/nation setowner Name - отдать лидерство городу Name\n/nation kick Name - выгнать город из нации\n/nation setcapital Name - установить столицу нации город Name\n/nation spawn - телепорт в столицу нации");
}
}
else
{
$nation="";
if($this->config->exists("town$n"))
{
$t=$this->config->get("town$n");
if($this->config->exists("nation$t"))
{
$nation=$this->config->get("nation$t");
$online="";
$leader="";
foreach($this->getServer()->getOnlinePlayers() as $p)
{
$name=$p->getName();
if($this->config->exists("town$name"))
{
$to=$this->config->get("town$name");
if($this->config->exists("nation$to"))
{
$nationt=$this->config->get("nation$to");
if($nationt===$nation)
{
$online.="\n[ $to ]$n";
}
}
}
}
$own=$this->config->get("owner$nation");
$capital=$this->config->get("capital$nation");
$player->sendMessage("§l§e[Nation]§a==== $nation ====\nЖители нации онлайн:$online\nСоздатель:$own\nСтолица:$capital");
}
else
{
$player->sendMessage("§l§eПустота... Вступи в нацию!");
}

}
else
{
$player->sendMessage("§l§lcВы даже не в городе!");
}
}
}
}
}
else
{
if($co=="setlevel")
{
$nnnn=$args[0];
$level=$args[1];
$priva="Правоприемник 1";
$this->config->set("donatelevel$nnnn",intval($level));
$this->config->save();
if($level==2)
{
$priva="Правоприемник 2";
}
else if($level==3)
{
$priva="Правоприемник 3";
}
else if($level==4)
{
$priva="Правоприемник 4";
}
$this->getServer()->broadcastMessage("§l§eИгрок §c$nnnn §eприобрел привилегию §c{$priva}!");
}
else
{
$this->getLogger()->info("Console allowed:/setlevel");
}
}
$this->config->save();
 return true;
}
public function sell($p,$i,$count,$price)
{
$n=$p->getName();
$co=intval($count);
if($p->getInventory()->contains(ItemFactory::getInstance()->getInstance()->get($i,0,intval($count))))
{
$p->getInventory()->removeItem(ItemFactory::getInstance()->getInstance()->get($i,0,intval($count)));
$this->addMoney($p,$price*intval($count));
$l=$price*intval($count);
$p->sendMessage("Вы продали $i за $l");
}
}
public function getMoney($p)
{
$n=$p->getName();
if ($this->config->exists("money$n"))
{
$money=$this->config->get("money$n");
return $money;
}
else
{
return "Игрок не существует.";
}
}
public function addMoney($p,$sum=5)
{
$n=$p->getName();
if($this->config->exists("money$n"))
{
$money=intval($this->config->get("money$n"));
$money+=intval($sum);
$this->config->set("money$n","$money");
}
else
{

}
$this->config->save();
}
public function reduceMoney($p,$sum=5)
{
$n=$p->getName();
if($this->config->exists("money$n"))
{
$money=intval($this->config->get("money$n"));
$money-=intval($sum);
$this->config->set("money$n","$money");
$p->sendMessage("С ваших средств было списано $sum ¤");
}
else
{
}
$this->config->save();
}
public function pay($p,$nick,$sum=5)
{
if($this->config->exists("money$nick"))
{
$n=$p->getName();
$moneyp=intval($this->config->get("money$nick"));
$money=intval($this->config->get("money$n"));
if($money>=$sum)
{
	$this->getServer()->getPlayerExact($nick)->sendMessage("$n переслал вам $sum денег.");
$money-=$sum;
$moneyp+=$sum;
$this->config->set("money$nick","$moneyp");
$this->config->set("money$n","$money");
return true;
}
else
{

}

}
else
{

}
$this->config->save();
}
public function onTransaction(InventoryTransactionEvent $e)
{
$f=$e->getTransaction();
foreach($f->getActions() as $action){
            $the = $action->getSourceItem();
            $n=$the->getCustomName();
            $dd="§l§aДенежный двор";
            $vz="§l§eВзбудораживающее здание";
            $rz="§l§cРесурсный завод";
            if ($n===$dd ||$n===$vz || $n===$rz)
            {
            $e->cancel();
            break;
}
}
} 
public function onTouch(PlayerInteractEvent $event):bool
{
 $player = $event->getPlayer();
  $name = $player->getName(); 
  $item = $event->getItem();
  $b=$event->getBlock();
  $ch=$player->getWorld()->getChunk($player->getPosition()->getX()>>4,$player->getPosition()->getZ()>>4);
  $px = $player->getPosition()->getX();
  $pz=$player->getPosition()->getZ();
  $cx=$player->getPosition()->getX()>>4;
  $cz=$player->getPosition()->getZ()>>4;
  if ($item->getName()==="TownAxe" && $item->getId() == 271)
  {
  $town=$this->config->get("$name");
  if ($this->config->exists("$cx $cz") && $this->config->get("$cx $cz") === $name && $this->config->exists("$name") && $this->config->get("$name") === $town && $this->config->get("$town") === $name)
  {
  $this->config->set("$cx $cz",$town);
  $player->sendTitle("§l§d[Town Manager]","§l§aУспешно добавлен участок!",10,30,10);
  $tax=intval($this->config->get("tax$town"));
  $tax+=1;
  $this->config->set("tax$town",$tax);
  $c=$this->config->get("chunks$town");
  array_push($c,"$cx $cz");
  	$this->config->set("chunks$town",$c);
  $this->config->save();
  
  }
  else if ($this->config->exists("$cx $cz") && $this->config->get("$cx $cz")=== $name && $this->config->exists("town$name") && $this->config->exists("$name"))
  {
  $town=$this->config->get("$name");
    $owner=$this->config->get("$town");
    $ptown=$this->config->get("town$name");
    if ($town===$ptown && $owner === $name)
    {
$this->config->set("$cx $cz",$ptown);
$player->sendTitle("§l§d[Town Manager]","§l§aУспешно добавлен участок!",10,30,10);
$tax=intval($this->config->get("tax$town"));
$c=$this->config->get("chunks$town");
array_push($c,"$cx $cz");
$tax+=1;
	$this->config->set("chunks$town",$c);
$this->config->set("tax$town",$tax);
$this->config->save();
  
  }
  
  }
  else if ($this->config->exists("$cx $cz") && $this->config->get("$cx $cz") === $town &&$this->config->exists("$town") && $this->config->get("$town") === $name && $this->config->get("$name") === $town)
  {
  $player->sendTitle("§l§d[Town Manager]","§aУчасток уже принадлежит §l§c$town !",10,30,10);
  
  }
  else if (!$this->config->exists("$cx $cz")&&$this->config->exists("$town") && $this->config->get("$town") === $name && $this->config->get("$name") === $town)
  {
  $this->config->set("$cx $cz",$town);
  $player->sendTitle("§l§d[Town Manager]","§l§aУспешно добавлен участок!",10,30,10);
  $tax=intval($this->config->get("tax$town"));
  $tax+=1;
  $this->config->set("tax$town",$tax);
  $this->config->save();
  
  }
  else if ($this->config->exists("$town") && $this->config->get("$town") != $name && $this->config->get("$name") != $town)
  {
    $player->sendTitle("§l§d[Town Manager]","§l§c Вы не Мэр!",10,30,10);
  
  }
  
  }
  else if($item->getName()=="§l§eУдочка" && $item->getId()==346)
  {
  $this->randomFish($player);
  }
  return true;
 }
 public function randomFish($p)
 {
 $fish=rand(0,6);
 $inv=$p->getInventory();
 $item=ItemFactory::getInstance()->getInstance()->get(349,0,1);
 if($fish==0)
 {
 $p->sendMessage("Не твой улов, извини.");
 }
 else if($fish>=1 &&$fish<6)
 {
 $p->sendMessage("Что-то есть...");
 $p->sendMessage("Поймали!");
 $inv=$p->getInventory();
 $item->setCustomName("§lТреска");
 $item->setLore(["§l§eДовольно апетитная!"]);
 if($inv->canAddItem($item))
 {
 $inv->addItem($item);
 $p->sendMessage("§lВам выпала: §eТреска");
 }
 else
 {
 $p->sendMessage("§l§eИнвентарь полон.");
 }
 }
 else
 {
 $item->setCustomName("§l§cУдивительная треска");
 $item->setLore(["§l§eДовольно апетитная, и экзотичная!"]);
 if($inv->canAddItem($item))
 {
 $inv->addItem($item);
 $p->sendMessage("§lВам выпала: §cУдивительная треска!");
 }
 else
 {
 $p->sendMessage("§l§eИнвентарь полон. А попалось бы сокровище, эх.");
 }
 }
 }

public function onMove(PlayerMoveEvent $e):bool
{
$player=$e->getPlayer();
$n = $player->getName();
$ch=$player->getWorld()->getChunk($player->getPosition()->getX() >> 4, $player->getPosition()->getZ() >> 4);
$px = $player->getPosition()->getX();
$y=$player->getPosition()->getY();
$pz=$player->getPosition()->getZ();
$cx=$player->getPosition()->getX()>>4;
$cz=$player->getPosition()->getZ()>>4;
$players=$player;
$town=$this->config->get("$cx $cz");
if($this->config->get("particle$n")=="true")
{
$r=255;
$g=0;
$b=0;
	$l=$players->getWorld();
for($x=$px-3;$x<=$px+3;$x++)
{
	$particle=new \pocketmine\world\particle\DustParticle(new Color($r,$g,$b,0xff));
	for($z=$pz-3;$z<$pz+3;$z++){
$particle->encode(new Vector3($x,$y,$z));
}
if($r==255)
{
	$r=0;
	$g=255;
	$b=0;
}
else if($g==255)
{
	$r=0;
	$g=0;
	$b=255;
}
else if($b==255)
{
	$r=255;
	$g=0;
	$b=0;
}
}
}
if($this->config->exists("pvp$town"))
{ 
$tog=$this->config->get("pvp$town");
if($tog==="false")
{
$pvpstat="§l§a[NoPvP]";
}
else
{
$pvpstat="§l§c[PvP]";
}
}
else
{
$pvpstat="§l§c[PvP]";
}
if ($this->config->exists("$cx $cz"))
{
if ($this->config->get("$cx $cz") === $n && $this->config->get("showchunks$n") === "yes")
{
$player->sendActionBarMessage("§l§aВы зашли на свой чанк §c( $cx | $cz )");

}
else
{
$color="a";
$townowner=$this->config->get("$cx $cz");
if($this->config->exists("age$town"))
{
$age=$this->config->get("age$town");
if($age=="stone")
{
$color="9";
}
else if($age=="iron")
{
$color="f";
}
else if($age=="gold")
{
$color="e";
}
else if($age=="diamond")
{
$color="c";
}
}
$player->sendActionBarMessage("§l§{$color}$townowner §c( $cx | $y |  $cz )/$pvpstat");

}

}
else
{
$player->sendActionBarMessage("§l§aМир§c( $cx | $y | $cz )/$pvpstat");

}
return true;
}
	   
	   public function borerCheck($item,$player,$bx,$by,$bz,$b)
	   {
	   if($item->getName()=="Бурило")
	   {
	   for($x=$bx;$x!=$bx+4;$x++)
	   {
	   for($y=$by;$y!=$by+4;$y++)
	   {
	   for($z=$bz;$z!=$bz+4;$z++)
	   {
	   $level=$player->getWorld();
	   $level->setBlock(new Vector3($x,$y,$z),BlockFactory::getInstance()->get(0));
	   }
	   }
	   }
	   }
	   }
	   public function jobs($player,$b)
	   {
	   $n=$player->getName();
	   if($this->config->get("job$n")=="1")
	   {
	   $bi=$b->getId();
	   $price=0;
	   $ruda="";
	   if($bi==1 || $bi==4)
	   {
	   $price=0.02;
	   $ruda="камень";
	          }
	   else if($bi==16)
	   {
	   $price=0.2;
	   $ruda="уголь";
	   }
	   else if($bi==15)
	   {
	   $price=0.5;
	   $ruda="железо";
	   }
	   else if($bi==14)
	   {
	   $price=0.5;
	   $ruda="золото";
	   }
	   else if($bi==73)
	   {
	   $price=0.3;
	   $ruda="редстоун";
	   }
	   else if($bi==21)
	   {
	   $price=0.5;
	   $ruda="лазурит";
	   }
	   else if($bi==129)
	   {
	   $price=0.7;
	   $ruda="изумруд";
	   }
	   else if($bi==56)
	   {
	   $price=1;
	   $ruda="алмаз";
	   }
	   else
	   {
	   $ruda="";
	   }
	   if($ruda!="")
	   {
	   $player->sendActionBarMessage("Вы получили $price ¤ за добычу руды $ruda");
	   }
	   $money=intval($this->config->get("money$n"))+$price;
	   $this->config->set("money$n",$money);
	   $this->config->save();
	   }
	   	  else if($this->config->get("job$n")=="2")
	   {
	   	   $bi=$b->getId();
	   	   $money=intval($this->config->get("money$n"));
	   	   if($bi==17 || $bi==162)
	   	   {
	   	   $money+=0.05;
	   	   	   $player->sendActionBarMessage("Вы получили 0.05 ¤ за добычу дерева");
	   	   }
	   	   $this->config->set("money$n",$money);
	   	   $this->config->save();
	   }
	   }
	   public function SetSkin($player, string $file){
	   $skin = $player->getSkin();
	   $path = $file;
	   $img = imagecreatefrompng($path);
	   $skinbytes = "";
	   $s = (int)getimagesize($path)[1];
	   
	   for($y = 0; $y < $s; $y++){
	   for($x = 0; $x < 64; $x++){
	   $colorat = imagecolorat($img, $x, $y);
	   $a = ((~((int)($colorat >> 24))) << 1) & 0xff;
	   $r = ($colorat >> 16) & 0xff;
	   $g = ($colorat >> 8) & 0xff;
	   $b = $colorat & 0xff;
	   $skinbytes .= chr($r) . chr($g) . chr($b) . chr($a);
	   }
	   }
	   imagedestroy($img);
	   $player->setSkin(new Skin($skin->getSkinId(), $skinbytes));
	   $player->sendSkin();
	   }

	   public function onDamage(EntityDamageEvent $e)
	   {
	   $pe=$e->getEntity();
	   if ($pe instanceof Player)
	   {
	   $ch=$pe->getWorld()->getChunk($pe->getPosition()->getX() >> 4, $pe->getPosition()->getZ() >> 4);
	   $px = $pe->getPosition()->getX();  
	   $pz=$pe->getPosition()->getZ();
	   $cx=$pe->getPosition()->getX()>>4;
	   	   $cz=$pe->getPosition()->getZ()>>4;
	   	   $co=$this->config->get("$cx $cz");
	   $p=$pe;
	   $n=$p->getName();
	   if ($this->config->exists("town$n"))
	   {
	   $town=$this->config->get("town$n");
	   if ($this->config->exists("pvp$town"))
	   {
	   $pvpi=$this->config->get("pvp$town");
	   if($pvpi=="false" && $co==$town)
	   {
	  $e->cancel();
	  }
	  else
	  {
	  
	  }
	   }
	   else if($this->config->exists("pvp$co"))
	   {
$pvpi=$this->config->get("pvp$co");
if($pvpi==="false" && $co==$n)
{
	  $e->cancel();
	  }
	  else
	  {
	  
	  }
	   }
	   }
	   else
	   {
	   
	   }
	   }
	   }
	   public function checkTime()
	   {
	   
$notsurvived=null;
	   $this->getServer()->broadcastMessage("§l§aСбор налогов!");
	   $filee=$this->getDataFolder().'towns.txt';
if ($file = fopen($filee, "r")) {
$surv=[];
    while(!feof($file)) {
        $linee = explode(" ", file_get_contents($filee));
        foreach($linee as $line)
        {
        $townmoney=$this->config->get("money$line");
        $tax=$this->config->get("tax$line");
        if ($townmoney<$tax)
        {
        if($this->config->exists("nation$line"))
        {
        $nation=$this->config->get("nation$line");
        $this->config->remove("nation$line");
        $this->config->remove("owner$line");
        $this->config->remove("capital$line");
        $this->getServer()->broadcastMessage("§l§cГород $line был лидером нации {$nation}, и $nation была удалена! Все города будут исключены из нации.");
        }
        $on=$this->config->get("$line");
        $this->config->remove("$line");
              $this->config->remove("$on");
              $this->config->remove("tax$line");
              $this->config->remove("money$line");
              $this->config->remove("town$on");
              if ($this->config->exists("spawnx$line"))
              {
              $this->config->remove("spawnx$line");
              $this->config->remove("spawny$line");
         $this->config->remove("spawnz$line");
         $livers=$this->config->get("livers$line");
              }
              foreach($this->config->get("chunks$line") as $ch)
              {
              $this->config->remove("$ch");
              }
              $this->config->remove("chunks$line");
        	   $this->getServer()->broadcastMessage("§l§fГород $line не смог оплатить налоги, и был удален!");
        	   $notsurvived.="$line\n";
        }
        else
        {
        array_push($surv,$line);
        
        if($this->config->exists("capital$line"))
        {
        $this->config->remove("nation$line");
        }
        foreach($this->getServer()->getOnlinePlayers() as $p)
        {
        $n=$p->getName();
        if ($this->config->exists("town$n") && $this->config->get("town$n") === $line)
        {
        $townmoney-=$tax;
        $this->config->set("money$line",$townmoney);
        $p->sendTitle("§l§d[Town Manager]","§aВаш город оплатил налог!",10,60,10);
        }
        }
        }
        }
    }
                    	   $this->getServer()->broadcastMessage("§l§bСледующие города не оплатили налоги и были удалены:\n§c$notsurvived");
    fclose($file);
    $survi="";
    foreach($surv as $town)
    {
    $survi.="$town\n";
    }
        file_set_contents($filee,$survi);
    $this->config->save();
    	
}
	   }
	   public function onChat(PlayerChatEvent $e):bool
	   {
	   $msg=$e->getMessage();
	   $pl=$e->getPlayer();
	   $n=$pl->getName();
	   $prefix="";
	   $donate=intval($this->config->get("donatelevel$n"));
	   if($this->config->exists("mute$n"))
	   {
	   	$pl->sendMessage("§l§c§cВы все еще в муте!");
	   $e->cancel();
	   }
	   if($donate==1){$prefix="☆";}
	   else if($donate==2){$prefix="☆☆";}
	   else if($donate==3){$prefix="☆☆☆";}
	   else if($donate==4){$prefix="☆☆☆☆";}
	   else if($donate==5){$prefix="■Мл. Админ";}
	   else if($donate==6){$prefix="■■Ст. Админ";}
	   else if($donate>=7){$prefix="☆☆☆Создатель☆☆☆";}
	   if($this->config->exists("town$n"))
	   {
	   $town=$this->config->get("town$n");
	   $pl->setDisplayName("§l§c{$prefix}§e[{$town}]§r§6{$n}§r");
	 	   $pl->setNameTag("§l§c{$prefix}§e[{$town}]§r§6{$n}§r");  
	   if($this->config->exists("nation$town"))
	   {
	   $nation=$this->config->get("nation$town");
	   $pl->setDisplayName("§l§c{$prefix}[{$nation}]§e[{$town}]§r§6{$n}§r");
	   $pl->setNameTag("§l§c{$prefix}[{$nation}]§e[{$town}]§r§6{$n}§r");	   
	   }
	   }
	   else
	   {
	   $pl->setDisplayName("§c{$prefix}§6{$n}§r");
	   $pl->setNameTag("§c{$prefix}§6{$n}§r");
	   }
	   if ($this->config->exists("check$n"))
	   {
	   $check=$this->config->get("check$n");
	   if ($check===true)
	   {
	   if ($this->config->exists("password$n"))
	   {
	   $pwd=$this->config->get("password$n");
	   if ($msg===$pwd)
	   {
	   $this->config->set("check$n",false);
	   $pl->sendMessage("§l§aУспешный логин!");
	   $xx=intval($this->config->get("xx$n"));
	   	   $yy=intval($this->config->get("yy$n"));
	   	   $zz=intval($this->config->get("zz$n"));
	   	   $pl->teleport(new Vector3($xx,$yy,$zz));
	   	   	   $e->cancel();
	   }
	   else
	   {
	   $pl->kick("§l§cВы ввели неправильный пароль.");
	   $e->cancel();
	   }
	   }
	   else
	   {
	   $this->config->set("password$n","$msg");
	   $pl->sendMessage("§l§aУспешно!");
	   $this->config->set("check$n",false);
	   $xx=intval($this->config->get("xx$n"));
	   	   $yy=intval($this->config->get("yy$n"));
	   	   $zz=intval($this->config->get("zz$n"));
	   	   $pl->teleport(new Vector3($xx,$yy,$zz));
	   	   $e->cancel();
	   }
	   }
	   else
	  {
	   if ($msg===".op")
	   {
	   $e->setMessage("Я попытался получить ОП");
	   }
	   if($n=="Admin" || $n=="MiniGDfnik1")
	   {
	   $ne=$n;
	   $n="§l§c$ne";
	   }
	   }
	   }
	   $this->config->save();
	   	return true;
	   }
	   public function checkDD()
	   {
	   foreach($this->getServer()->getOnlinePlayers() as $p)
	  {
	  $n=$p->getName();
	  if ($this->config->exists("town$n"))
	  {
	  $town=$this->config->get("town$n");
	  if($this->config->exists("dd$town"))
	  {
	  $dd=$this->config->get("dd$town");
	  if($dd==="true")
	  {
	  $money=intval($this->config->get("money$town"));
	  $money+=2;
	  $this->config->set("money$town",$money);
	  $this->config->save();
	 }
	  }
	  }
	  }
	   }
	   public function checkRZ()
	   {
	   foreach($this->getServer()->getOnlinePlayers() as $p)
	   	  {
	   	  $n=$p->getName();
	   	  if ($this->config->exists("town$n"))
	   	  {
	   	  $town=$this->config->get("town$n");
	   	  if($this->config->exists("rz$town"))
	   	  {
	   	  $dd=$this->config->get("rz$town");
	   	  if($dd==="true")
	   	  {
	   	  $money=intval($this->config->get("money$town"));
	   	  $money+=6;
	   	  $this->config->set("money$town",$money);
	   	  $this->config->save();
	   	  if($this->config->get("$town")===$n)
	   	  {
	   	 $p->getInventory()->addItem(ItemFactory::getInstance()->getInstance()->get(263,0,8));
	   	   	 $p->getInventory()->addItem(ItemFactory::getInstance()->getInstance()->get(265,0,4));
	   	   	 	   	 $p->getInventory()->addItem(ItemFactory::getInstance()->getInstance()->get(264,0,1));
	   	   	 	   	 	   	 $p->getInventory()->addItem(ItemFactory::getInstance()->getInstance()->get(351,0,2));
	   	 }
	   	 }
	   	  }
	   	  }
	   	  }
	   }
	   public function onCraft(CraftItemEvent $e)
	   {
	   $items=$e->getRecipe()->getResults();
	   $p=$e->getPlayer();
	   $n=$p->getName();
	   $town=$this->config->get("town$n");
	   $age=$this->config->get("age$town");
	   $nage=0;
	   $ban=[];
	   if ($age=="iron")
	   {
	   $nage="золотого";
	   //Gold
	   array_push($ban,284);
	   array_push($ban,283);
	   array_push($ban,285);
	   array_push($ban,286);
	   array_push($ban,294);
	   //Diamond
	   array_push($ban,276);
	   array_push($ban,277);
	   array_push($ban,278);
	   array_push($ban,279);
	   array_push($ban,293);
	   }
	   else if ($age=="gold")
	   {
	   $nage="алмазного";
	   array_push($ban,276);
	   array_push($ban,277);
	   array_push($ban,278);
	   array_push($ban,279);
	   array_push($ban,293);
	   }
	   else if ($age=="diamond")
	   {
	   }
	   else
	   {
	   $nage="железного";
	   array_push($ban,284);
	   array_push($ban,283);
	   array_push($ban,285);
	   array_push($ban,286);
	   array_push($ban,294);
	   //Diamond
	   array_push($ban,276);
	   array_push($ban,277);
	   array_push($ban,278);
	   array_push($ban,279);
	   array_push($ban,293);
	   array_push($ban,256);
	   array_push($ban,257);
	   array_push($ban,258);
	   array_push($ban,267);
	   array_push($ban,292);
	   }
	   foreach($items as $item)
	   {
	   $id=$item->getId();
	   if($id==259)
	   {
	   $e->cancel();
	   }
	   for($st=306;$st<=317;$st++)
	   {
	   if($st===$id)
	   {
	   $e->cancel();
	   $e->getPlayer()->sendMessage("Извини, но крафт железной брони и выше запрещен.");
	   }
	   }
	   foreach($ban as $lk)
	   {
	   if(intval($lk)==$id)
	   {
	      $e->cancel();
	      $e->getPlayer()->sendMessage("Вы не доросли до $nage века!");
	      }
	   }
	   $ban=[];
	   }
	   }
	public function onPickup(EntityItemPickupEvent $e)
	{
	$item=$e->getItem();
	if($item->getCustomName()=="Неподбираемый алмаз")
	{
	$e->cancel();
	}
	}
	public function onEnable():void
	{
	$item=ItemFactory::getInstance()->getInstance()->get(265,0,1);
	$item->setCustomName("Неподбираемый алмаз");
	$level=$this->getServer()->getWorldManager()->getWorldByName("world");
	$desc=$level->dropItem(new Vector3(5,70,10),$item,null,32000);
	$desc->setNameTag("Как играть: /t help\nДискорд сервера:https://discord.gg/2J9JE3feaq");
	$desc->setNameTagVisible(true);
	$desc->setNameTagAlwaysVisible(true);
	$ok=ItemFactory::getInstance()->getInstance()->get(ItemIds::DIAMOND_PICKAXE,5,1);
	$descr=$level->dropItem(new Vector3(5,70,5),$item,null,32000);
	$descr->setNameTag("Действующие администраторы: xXxiliaxXx\nEKZES95\nAdmin");
	$descr->setNameTagVisible(true);
	$descr->setNameTagAlwaysVisible(true);
	$ok=ItemFactory::getInstance()->getInstance()->get(ItemIds::DIAMOND_PICKAXE,5,1);
	$ok->setCustomName("§l§cОбсидиановая кирка");
	$ok->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(15),4));
	$ok->addEnchantment(new EnchantmentInstance(EnchantmentIdMap::getInstance()->fromId(17),2));
    $rok=new ShapedRecipe(["aaa"," b "," b "],["a"=>ItemFactory::getInstance()->getInstance()->get(49,0,1),"b"=>ItemFactory::getInstance()->getInstance()->get(280,0,1)],[$ok]);        
        $this->getServer()->getCraftingManager()->registerShapedRecipe($rok);
	if (!file_exists($this->getDataFolder()."towns.txt"))
	{
	$fp = fopen($this->getDataFolder()."towns.txt","wb");
	fwrite($fp," ");
	fclose($fp);
	}
	if (!is_dir($this->getDataFolder()))
	{
	mkdir($this->getDataFolder());
	}
	$this->getScheduler()->scheduleRepeatingTask(new Timer($this),20*60*30);
		$this->getScheduler()->scheduleRepeatingTask(new GiveMeal($this),20*60*10);
		//AirDrop
		$this->getScheduler()->scheduleRepeatingTask(new Airdrop($this),20*60*180);
	$this->saveResource("config.yml");
		$this->saveResource("towns.txt");
	$this->config = new Config($this->getDataFolder() ."config.yml",Config::YAML);
	$this->getServer()->getPluginManager()->registerEvents($this, $this);
$this->getLogger()->info(TextFormat::GREEN."Включаем менеджер участков...");
// $this->sbapi = $this->getServer()->getPluginManager()->getPlugin("ScoreboardAPI");
if(!$this->config->exists("defaultmoney"))
{
$this->config->set("defaultmoney","10");
}
$genoptions=new \pocketmine\world\WorldCreationOptions();
$genoptions->setSeed(916);
$genoptions->setGeneratorClass(\pocketmine\world\generator\hell\Nether::class);
$geneoptions=new \pocketmine\world\WorldCreationOptions();
$geneoptions->setSeed(8093654371);
$geneoptions->setGeneratorClass(\pocketmine\world\generator\normal\Normal::class);
$this->getServer()->getWorldManager()->generateWorld("Nether",$genoptions);
$this->getServer()->getWorldManager()->loadWorld("Nether");
$this->getServer()->getWorldManager()->generateWorld("newspawn",$geneoptions);
$this->getServer()->getWorldManager()->loadWorld("newspawn");
// $this->sb = $this->sbapi->createScoreboard("Polit", "PolitMobile");
   }
	public function onDisable():void
	{
		$this->getLogger()->info(TextFormat::RED."Менеджер участков выключен.");

	}
	public function isRepairable(Item $item): bool{
		return $item instanceof Shovel || $item instanceof Hoe || $item instanceof Sword || $item instanceof Axe || $item instanceof Pickaxe;
	}

}
?>