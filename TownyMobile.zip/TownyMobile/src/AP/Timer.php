<?php
namespace AP;

use pocketmine\scheduler\Task;

class Timer extends Task
{
private $main;

public function __construct($main)
{
$this->main=$main;
}
public function onRun():void
{
$this->main->checkDD();
$this->main->checkRZ();
}
}