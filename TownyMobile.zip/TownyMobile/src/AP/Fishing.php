<?php
namespace AP;

use AP\AP;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
class Fishing extends AP
{
public $pl;
public function __construct($player)
{
$this->pl=$player;
$this->randomFish();
}
public function randomFish()
{
$p=$this->pl;
$fish=rand(0,6);
$time=rand(5,30);
if($fish==0)
{
$p->sendMessage("Не твой улов, извини.");
sleep(5);
}
else if($fish>=1 &&$fish<6)
{
$p->sendMessage("Что-то есть...");
sleep($time);
$p->sendMessage("Поймали!");
$inv=$p->getInventory();
$item=Item::get(349,0,1);
$item->setCustomName("§lТреска");
$item->setLore(["§l§eДовольно апетитная!"]);
if($inv->canAddItem($item))
{
$inv->addItem($item);
$player->sendMessage("§lВам выпала: §eТреска");
}
else
{
$player->sendMessage("§l§eИнвентарь полон.");
}
}
else
{
$item->setCustomName("§l§cУдивительная треска");
$item->setLore(["§l§eДовольно апетитная, и экзотичная!"]);
if($inv->canAddItem($item))
{
$inv->addItem($item);
$player->sendMessage("§lВам выпала: §cУдивительная треска!");
}
else
{
$player->sendMessage("§l§eИнвентарь полон. А попалось бы сокровище, эх.");
}
}
}
}
?>